"""
Bull Put Spread Strategy
Sell OTM Put + Buy further OTM Put (lower strike)
Credit spread - profits when index stays above short put
"""
from typing import Dict, Optional
from analytics.greeks import black_scholes_greeks, time_to_expiry_years, get_risk_free_rate
from config import LOT_SIZE


def find_bull_put_spread(
    spot_price: float,
    option_chain: list,
    expiry_date,
    target_otm_pct: float = 0.03
) -> Optional[Dict]:
    """
    Find optimal Bull Put Spread setup

    Sell OTM Put (higher strike) + Buy further OTM Put (lower strike)
    Profits when price stays above short put strike
    """
    import pandas as pd
    chain_df = _prepare_chain(option_chain)
    if chain_df is None or len(chain_df) < 5:
        return None

    T = time_to_expiry_years(expiry_date)
    r = get_risk_free_rate()
    lot_size = LOT_SIZE.get("BANKNIFTY", 15)

    pe_df = chain_df[chain_df["type"] == "PE"].sort_values("strike")

    # Short put: ~3% OTM
    short_put_strike = spot_price * (1 - target_otm_pct)
    short_put = _closest_strike(pe_df, short_put_strike)
    if not short_put or short_put["ltp"] <= 0:
        return None

    # Long put: ~5-6% OTM (1-2% wider)
    long_put_strike = spot_price * (1 - target_otm_pct - 0.02)
    long_put = _closest_strike(pe_df, long_put_strike)
    if not long_put or long_put["ltp"] <= 0:
        return None

    # Ensure long strike < short strike
    if long_put["strike"] >= short_put["strike"]:
        # Find next lower strike
        for _, row in pe_df.iterrows():
            if row["strike"] < short_put["strike"] and row["ltp"] > 0:
                long_put = row.to_dict()
                break

    spread_width = short_put["strike"] - long_put["strike"]
    net_credit = short_put["ltp"] - long_put["ltp"]
    max_profit = net_credit * lot_size
    max_risk = spread_width * lot_size - max_profit
    margin = max_risk  # Bull put spread: max risk is margin

    if max_risk <= 0 or net_credit <= 0:
        return None

    return {
        "strategy": "Bull Put Spread",
        "short_put_strike": short_put["strike"],
        "long_put_strike": long_put["strike"],
        "short_put_premium": round(short_put["ltp"], 2),
        "long_put_premium": round(long_put["ltp"], 2),
        "net_credit": round(net_credit, 2),
        "max_profit": round(max_profit, 2),
        "max_risk": round(max_risk, 2),
        "margin": round(margin, 2),
        "spread_width": spread_width,
        "expected_theta": round(short_put.get("theta", 0) * lot_size, 2),
        "risk_reward_ratio": round(max_risk / max_profit, 2) if max_profit > 0 else 999,
        "iv_short": round(short_put.get("iv", 0), 1),
        "delta_short": round(short_put.get("delta", 0), 4),
        "strikes": {
            "short_put": short_put["strike"],
            "long_put": long_put["strike"]
        }
    }


def _prepare_chain(option_chain: list):
    import pandas as pd
    if not option_chain:
        return None
    df = pd.DataFrame(option_chain)
    if df.empty:
        return None
    for col in ["ltp", "iv", "delta", "theta", "oi", "bid", "ask"]:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0)
    return df


def _closest_strike(df, target_strike: float) -> Optional[dict]:
    if df.empty:
        return None
    best = None
    min_diff = float("inf")
    for _, row in df.iterrows():
        if row["ltp"] > 0 and row["oi"] > 500:
            diff = abs(row["strike"] - target_strike)
            if diff < min_diff:
                min_diff = diff
                best = row.to_dict()
    return best
