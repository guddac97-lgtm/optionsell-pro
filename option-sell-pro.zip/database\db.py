"""
SQLite Database setup and CRUD operations for OptionSell Pro
"""
import sqlite3
import json
from datetime import datetime
from config import DB_PATH


def get_connection():
    """Get database connection"""
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    """Initialize all tables"""
    conn = get_connection()
    cursor = conn.cursor()

    # Recommendations table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS recommendations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            date TEXT NOT NULL,
            strategy TEXT NOT NULL,
            index_name TEXT NOT NULL,
            expiry_date TEXT NOT NULL,
            strikes TEXT NOT NULL,
            max_profit REAL,
            max_risk REAL,
            expected_theta REAL,
            margin_required REAL,
            score INTEGER,
            iv_rank INTEGER,
            adx REAL,
            pcr REAL,
            liquidity_score INTEGER,
            factors TEXT,
            executed BOOLEAN DEFAULT 0,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    """)

    # Positions table (open trades)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS positions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            strategy TEXT NOT NULL,
            index_name TEXT NOT NULL,
            expiry_date TEXT NOT NULL,
            strikes TEXT NOT NULL,
            entry_premium REAL NOT NULL,
            max_profit REAL NOT NULL,
            max_risk REAL NOT NULL,
            margin_used REAL NOT NULL,
            score INTEGER,
            status TEXT DEFAULT 'OPEN',
            current_pnl REAL DEFAULT 0,
            profit_pct REAL DEFAULT 0,
            dte_left INTEGER,
            upstox_order_ids TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            closed_at TEXT
        )
    """)

    # Trade journal (closed trades)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS trade_journal (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            strategy TEXT NOT NULL,
            index_name TEXT NOT NULL,
            entry_date TEXT NOT NULL,
            exit_date TEXT,
            expiry_date TEXT NOT NULL,
            strikes TEXT NOT NULL,
            entry_premium REAL NOT NULL,
            exit_premium REAL NOT NULL,
            gross_pnl REAL NOT NULL,
            charges REAL DEFAULT 0,
            net_pnl REAL NOT NULL,
            max_profit REAL NOT NULL,
            max_risk REAL NOT NULL,
            result TEXT NOT NULL,
            exit_reason TEXT,
            dte_at_exit INTEGER,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    """)

    # Settings table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL,
            updated_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    """)

    # Backtest results table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS backtest_results (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            strategy TEXT NOT NULL,
            index_name TEXT NOT NULL,
            start_date TEXT NOT NULL,
            end_date TEXT NOT NULL,
            capital REAL NOT NULL,
            total_trades INTEGER,
            win_rate REAL,
            total_profit REAL,
            avg_rr REAL,
            max_drawdown REAL,
            results_json TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    """)

    conn.commit()
    conn.close()


# ─── Recommendation CRUD ─────────────────────────────────────────
def save_recommendation(rec: dict):
    """Save a recommendation to database"""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO recommendations
        (date, strategy, index_name, expiry_date, strikes, max_profit, max_risk,
         expected_theta, margin_required, score, iv_rank, adx, pcr, liquidity_score, factors)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        rec["date"], rec["strategy"], rec["index_name"], rec["expiry_date"],
        json.dumps(rec["strikes"]), rec.get("max_profit", 0), rec.get("max_risk", 0),
        rec.get("expected_theta", 0), rec.get("margin_required", 0),
        rec.get("score", 0), rec.get("iv_rank", 0), rec.get("adx", 0),
        rec.get("pcr", 0), rec.get("liquidity_score", 0),
        json.dumps(rec.get("factors", {}))
    ))
    conn.commit()
    rec_id = cursor.lastrowid
    conn.close()
    return rec_id


def get_today_recommendations():
    """Get today's recommendations"""
    conn = get_connection()
    cursor = conn.cursor()
    today = datetime.now().strftime("%Y-%m-%d")
    cursor.execute(
        "SELECT * FROM recommendations WHERE date = ? ORDER BY score DESC",
        (today,)
    )
    rows = cursor.fetchall()
    conn.close()
    return [dict(row) for row in rows]


def mark_recommendation_executed(rec_id: int):
    """Mark recommendation as executed"""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute(
        "UPDATE recommendations SET executed = 1 WHERE id = ?",
        (rec_id,)
    )
    conn.commit()
    conn.close()


# ─── Position CRUD ───────────────────────────────────────────────
def save_position(pos: dict):
    """Save a new position"""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO positions
        (strategy, index_name, expiry_date, strikes, entry_premium, max_profit,
         max_risk, margin_used, score, upstox_order_ids)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        pos["strategy"], pos["index_name"], pos["expiry_date"],
        json.dumps(pos["strikes"]), pos["entry_premium"],
        pos["max_profit"], pos["max_risk"], pos["margin_used"],
        pos.get("score", 0), json.dumps(pos.get("upstox_order_ids", []))
    ))
    conn.commit()
    pos_id = cursor.lastrowid
    conn.close()
    return pos_id


def get_open_positions():
    """Get all open positions"""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute(
        "SELECT * FROM positions WHERE status = 'OPEN' ORDER BY created_at DESC"
    )
    rows = cursor.fetchall()
    conn.close()
    return [dict(row) for row in rows]


def close_position(pos_id: int, exit_premium: float, exit_reason: str = ""):
    """Close a position and move to journal"""
    conn = get_connection()
    cursor = conn.cursor()

    # Get position details
    cursor.execute("SELECT * FROM positions WHERE id = ?", (pos_id,))
    pos = dict(cursor.fetchone())

    entry_premium = pos["entry_premium"]
    max_profit = pos["max_profit"]
    max_risk = pos["max_risk"]
    gross_pnl = entry_premium - exit_premium  # Credit spread: entry - exit

    # Calculate charges (approximate)
    charges = entry_premium * 0.001 + exit_premium * 0.001 + 20  # STT + brokerage estimate
    net_pnl = gross_pnl - charges

    result = "WON" if net_pnl > 0 else "LOST"

    # Insert into journal
    cursor.execute("""
        INSERT INTO trade_journal
        (strategy, index_name, entry_date, exit_date, expiry_date, strikes,
         entry_premium, exit_premium, gross_pnl, charges, net_pnl,
         max_profit, max_risk, result, exit_reason)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        pos["strategy"], pos["index_name"], pos["created_at"],
        datetime.now().strftime("%Y-%m-%d %H:%M"), pos["expiry_date"],
        pos["strikes"], entry_premium, exit_premium,
        gross_pnl, charges, net_pnl, max_profit, max_risk,
        result, exit_reason
    ))

    # Update position status
    cursor.execute("""
        UPDATE positions SET status = 'CLOSED', closed_at = ?, current_pnl = ?
        WHERE id = ?
    """, (datetime.now().strftime("%Y-%m-%d %H:%M"), net_pnl, pos_id))

    conn.commit()
    conn.close()
    return net_pnl, result


def update_position_pnl(pos_id: int, current_pnl: float, profit_pct: float, dte_left: int):
    """Update live P&L for a position"""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        UPDATE positions SET current_pnl = ?, profit_pct = ?, dte_left = ?
        WHERE id = ?
    """, (current_pnl, profit_pct, dte_left, pos_id))
    conn.commit()
    conn.close()


# ─── Journal CRUD ────────────────────────────────────────────────
def get_journal_trades(limit: int = 50):
    """Get closed trades from journal"""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT * FROM trade_journal ORDER BY created_at DESC LIMIT ?
    """, (limit,))
    rows = cursor.fetchall()
    conn.close()
    return [dict(row) for row in rows]


def get_monthly_stats():
    """Get current month's trading stats"""
    conn = get_connection()
    cursor = conn.cursor()
    month_prefix = datetime.now().strftime("%Y-%m")

    cursor.execute("""
        SELECT
            COUNT(*) as total_trades,
            SUM(CASE WHEN result = 'WON' THEN 1 ELSE 0 END) as wins,
            SUM(CASE WHEN result = 'LOST' THEN 1 ELSE 0 END) as losses,
            SUM(net_pnl) as net_pnl,
            AVG(CASE WHEN result = 'WON' THEN net_pnl ELSE 0 END) as avg_win,
            AVG(CASE WHEN result = 'LOST' THEN net_pnl ELSE 0 END) as avg_loss
        FROM trade_journal
        WHERE entry_date LIKE ?
    """, (f"{month_prefix}%",))

    row = cursor.fetchone()
    conn.close()

    if row and row["total_trades"] > 0:
        win_rate = (row["wins"] / row["total_trades"]) * 100
        avg_rr = abs(row["avg_win"] / row["avg_loss"]) if row["avg_loss"] != 0 else 0
        return {
            "total_trades": row["total_trades"],
            "wins": row["wins"],
            "losses": row["losses"],
            "win_rate": round(win_rate, 1),
            "net_pnl": round(row["net_pnl"], 2),
            "avg_rr": round(avg_rr, 2)
        }
    return {"total_trades": 0, "wins": 0, "losses": 0, "win_rate": 0, "net_pnl": 0, "avg_rr": 0}


# ─── Settings CRUD ───────────────────────────────────────────────
def get_setting(key: str, default: str = ""):
    """Get a setting value"""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT value FROM settings WHERE key = ?", (key,))
    row = cursor.fetchone()
    conn.close()
    return row["value"] if row else default


def set_setting(key: str, value: str):
    """Set a setting value"""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT OR REPLACE INTO settings (key, value, updated_at)
        VALUES (?, ?, ?)
    """, (key, value, datetime.now().strftime("%Y-%m-%d %H:%M")))
    conn.commit()
    conn.close()


# ─── Backtest CRUD ───────────────────────────────────────────────
def save_backtest_result(result: dict):
    """Save backtest results"""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO backtest_results
        (strategy, index_name, start_date, end_date, capital, total_trades,
         win_rate, total_profit, avg_rr, max_drawdown, results_json)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        result["strategy"], result["index_name"], result["start_date"],
        result["end_date"], result["capital"], result["total_trades"],
        result["win_rate"], result["total_profit"], result["avg_rr"],
        result.get("max_drawdown", 0), json.dumps(result)
    ))
    conn.commit()
    conn.close()
