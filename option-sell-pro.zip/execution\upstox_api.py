"""
Upstox API v2 wrapper for live data and order execution
"""
import requests
import json
import time
from datetime import datetime, timedelta
from config import (
    UPSTOX_API_KEY, UPSTOX_API_SECRET, UPSTOX_ACCESS_TOKEN,
    UPSTOX_BASE_URL, INDICES
)


class UpstoxAPI:
    """Wrapper for Upstox API v2"""

    def __init__(self):
        self.access_token = UPSTOX_ACCESS_TOKEN
        self.headers = {
            "Authorization": f"Bearer {self.access_token}",
            "Content-Type": "application/json",
            "Accept": "application/json"
        }

    def _get(self, endpoint: str, params: dict = None):
        """GET request to Upstox API"""
        url = f"{UPSTOX_BASE_URL}{endpoint}"
        try:
            resp = requests.get(url, headers=self.headers, params=params, timeout=15)
            if resp.status_code == 200:
                return resp.json()
            elif resp.status_code == 401:
                return {"error": "Token expired", "status": resp.status_code}
            else:
                return {"error": resp.text, "status": resp.status_code}
        except Exception as e:
            return {"error": str(e), "status": 0}

    def _post(self, endpoint: str, data: dict = None):
        """POST request to Upstox API"""
        url = f"{UPSTOX_BASE_URL}{endpoint}"
        try:
            resp = requests.post(url, headers=self.headers, json=data, timeout=15)
            return resp.json() if resp.status_code == 200 else {"error": resp.text}
        except Exception as e:
            return {"error": str(e)}

    def get_profile(self):
        """Get user profile"""
        return self._get("/user/profile")

    def get_funds(self):
        """Get available funds/margin"""
        return self._get("/user/get-funds-and-margin")

    def get_instruments(self):
        """Get all instruments list (for symbol mapping)"""
        return self._get("/instrument/list")

    def get_historical_data(self, instrument_key: str, interval: str = "1day",
                            from_date: str = None, to_date: str = None):
        """Get historical candle data"""
        if not from_date:
            from_date = (datetime.now() - timedelta(days=365)).strftime("%Y-%m-%d")
        if not to_date:
            to_date = datetime.now().strftime("%Y-%m-%d")

        params = {
            "instrument_key": instrument_key,
            "interval": interval,
            "from": from_date,
            "to": to_date
        }
        return self._get("/historical-candle/{instrument_key}/{interval}/{from}/{to}".format(
            instrument_key=instrument_key, interval=interval,
            from=from_date, to=to_date
        ))

    def get_ltp(self, instruments: list):
        """Get Last Traded Price for multiple instruments"""
        instrument_keys = ",".join(instruments)
        return self._get("/market-quote/ltp", params={"instrument_key": instrument_keys})

    def get_option_chain(self, instrument_key: str, expiry_date: str = None):
        """Get option chain for an index"""
        if not expiry_date:
            expiry_date = self._get_next_weekly_expiry()

        params = {"instrument_key": instrument_key, "expiry_date": expiry_date}
        return self._get("/option/chain", params=params)

    def _get_next_weekly_expiry(self) -> str:
        """Calculate next weekly expiry (Thursday)"""
        today = datetime.now()
        days_until_thursday = (3 - today.weekday()) % 7
        if days_until_thursday == 0 and today.hour >= 15:
            days_until_thursday = 7
        next_thursday = today + timedelta(days=days_until_thursday)
        return next_thursday.strftime("%Y-%m-%d")

    def get_next_expiries(self, instrument_key: str, count: int = 4):
        """Get upcoming expiry dates"""
        result = self._get("/option/expiry-dates", params={"instrument_key": instrument_key})
        if "data" in result:
            return result["data"][:count]
        return []

    def place_order(self, order_data: dict):
        """Place a single order"""
        return self._post("/order/place", data=order_data)

    def place_bracket_order(self, orders: list):
        """Place multiple orders (for spreads/condors)"""
        results = []
        for order in orders:
            result = self.place_order(order)
            results.append(result)
            time.sleep(0.5)  # Rate limiting
        return results

    def get_positions(self):
        """Get current open positions"""
        return self._get("/portfolio/positions")

    def get_order_status(self, order_id: str):
        """Check status of an order"""
        return self._get(f"/order/history", params={"order_id": order_id})

    def cancel_order(self, order_id: str):
        """Cancel an open order"""
        return self._post("/order/cancel", data={"order_id": order_id})


# Singleton instance
_upstox = None


def get_upstox() -> UpstoxAPI:
    """Get or create Upstox API instance"""
    global _upstox
    if _upstox is None:
        _upstox = UpstoxAPI()
    return _upstox
