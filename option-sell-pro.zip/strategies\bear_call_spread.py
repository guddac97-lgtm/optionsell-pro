"""
Bear Call Spread Strategy
Sell OTM Call + Buy further OTM Call (higher strike)
Credit spread - profits when index stays below short call
"""
from typing import Dict, Optional
import pandas as pd
from config import LOT_SIZE


def find_bear_call_spread(
    spot_price: float,
    option_chain: list,
    expiry_date,
    target_otm_pct: float = 0.03
) -> Optional[Dict]:
    """Find optimal Bear Call Spread setup"""
    chain_df = _prepare_chain(option_chain)
    if chain_df is None or len(chain_df) < 5:
        return None

    ce_df = chain_df[chain_df["type"] == "CE"].sort_values("strike")

    # Short call: ~3% OTM
    short_call_strike = spot_price * (1 + target_otm_pct)
    short_call = _closest_strike(ce_df, short_call_strike)
    if not short_call or short_call["ltp"] <= 0:
        return None

    # Long call: ~5-6% OTM
    long_call_strike = spot_price * (1 + target_otm_pct + 0.02)
    long_call = _closest_strike(ce_df, long_call_strike)
    if not long_call or long_call["ltp"] <= 0:
        return None

    if long_call["strike"] <= short_call["strike"]:
        for _, row in ce_df.iterrows():
            if row["strike"] > short_call["strike"] and row["ltp"] > 0:
                long_call = row.to_dict()
                break

    spread_width = long_call["strike"] - short_call["strike"]
    net_credit = short_call["ltp"] - long_call["ltp"]
    lot_size = LOT_SIZE.get("BANKNIFTY", 15)
    max_profit = net_credit * lot_size
    max_risk = spread_width * lot_size - max_profit
    margin = max_risk

    if max_risk <= 0 or net_credit <= 0:
        return None

    return {
        "strategy": "Bear Call Spread",
        "short_call_strike": short_call["strike"],
        "long_call_strike": long_call["strike"],
        "short_call_premium": round(short_call["ltp"], 2),
        "long_call_premium": round(long_call["ltp"], 2),
        "net_credit": round(net_credit, 2),
        "max_profit": round(max_profit, 2),
        "max_risk": round(max_risk, 2),
        "margin": round(margin, 2),
        "spread_width": spread_width,
        "expected_theta": round(short_call.get("theta", 0) * lot_size, 2),
        "risk_reward_ratio": round(max_risk / max_profit, 2) if max_profit > 0 else 999,
        "iv_short": round(short_call.get("iv", 0), 1),
        "delta_short": round(short_call.get("delta", 0), 4),
        "strikes": {
            "short_call": short_call["strike"],
            "long_call": long_call["strike"]
        }
    }


def _prepare_chain(option_chain: list):
    if not option_chain:
        return None
    df = pd.DataFrame(option_chain)
    if df.empty:
        return None
    for col in ["ltp", "iv", "delta", "theta", "oi", "bid", "ask"]:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0)
    return df


def _closest_strike(df, target_strike: float) -> Optional[dict]:
    if df.empty:
        return None
    best = None
    min_diff = float("inf")
    for _, row in df.iterrows():
        if row["ltp"] > 0 and row.get("oi", 0) > 500:
            diff = abs(row["strike"] - target_strike)
            if diff < min_diff:
                min_diff = diff
                best = row.to_dict()
    return best
