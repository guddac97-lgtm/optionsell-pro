"""
Configuration for OptionSell Pro
All user-configurable settings in one place
"""

import os
from dotenv import load_dotenv

load_dotenv()

# ─── User Settings ───────────────────────────────────────────────
CAPITAL = float(os.getenv("CAPITAL", 500000))  # Total trading capital in INR
MAX_RISK_PER_TRADE_PCT = float(os.getenv("MAX_RISK_PER_TRADE_PCT", 2.0))  # % of capital
MAX_PORTFOLIO_DEPLOY_PCT = float(os.getenv("MAX_PORTFOLIO_DEPLOY_PCT", 10.0))  # % of capital
PROFIT_BOOKING_PCT = float(os.getenv("PROFIT_BOOKING_PCT", 50.0))  # Book at 50% of max profit
STOP_LOSS_MULTIPLIER = float(os.getenv("STOP_LOSS_MULTIPLIER", 2.0))  # SL at 2x premium collected
MAX_DTE = int(os.getenv("MAX_DTE", 21))  # Max days to expiry
MIN_DTE = int(os.getenv("MIN_DTE", 3))  # Min days to expiry (avoid last 3 days)
MIN_IV_RANK = int(os.getenv("MIN_IV_RANK", 20))  # Minimum IV Rank to consider
MIN_OI = int(os.getenv("MIN_OI", 5000))  # Minimum open interest
MIN_SCORE = int(os.getenv("MIN_SCORE", 70))  # Minimum score to show recommendation
MAX_RECOMMENDATIONS = int(os.getenv("MAX_RECOMMENDATIONS", 5))  # Max recs per day

# ─── Strategy Toggles ────────────────────────────────────────────
ENABLE_IRON_CONDOR = os.getenv("ENABLE_IRON_CONDOR", "true").lower() == "true"
ENABLE_BULL_PUT_SPREAD = os.getenv("ENABLE_BULL_PUT_SPREAD", "true").lower() == "true"
ENABLE_BEAR_CALL_SPREAD = os.getenv("ENABLE_BEAR_CALL_SPREAD", "true").lower() == "true"
ENABLE_SHORT_STRANGLE = os.getenv("ENABLE_SHORT_STRANGLE", "false").lower() == "true"
ENABLE_NAKED_OPTIONS = os.getenv("ENABLE_NAKED_OPTIONS", "false").lower() == "true"

# ─── Scoring Weights ─────────────────────────────────────────────
WEIGHT_IV_RANK = 25
WEIGHT_TREND = 15
WEIGHT_DISTANCE_SR = 15
WEIGHT_DTE = 15
WEIGHT_PCR = 10
WEIGHT_OI_CONCENTRATION = 10
WEIGHT_LIQUIDITY = 5
WEIGHT_EVENT_FILTER = 5
# Total = 100

# ─── Universe ────────────────────────────────────────────────────
INDICES = ["NIFTY", "BANKNIFTY"]
INDEX_DISPLAY = {"NIFTY": "Nifty 50", "BANKNIFTY": "Bank Nifty"}
LOT_SIZE = {"NIFTY": 50, "BANKNIFTY": 15}

# ─── Upstox API ──────────────────────────────────────────────────
UPSTOX_API_KEY = os.getenv("UPSTOX_API_KEY", "")
UPSTOX_API_SECRET = os.getenv("UPSTOX_API_SECRET", "")
UPSTOX_ACCESS_TOKEN = os.getenv("UPSTOX_ACCESS_TOKEN", "")
UPSTOX_REDIRECT_URI = os.getenv("UPSTOX_REDIRECT_URI", "http://localhost:8501/callback")
UPSTOX_BASE_URL = "https://api.upstox.com/v2"

# ─── Telegram Alerts ─────────────────────────────────────────────
ENABLE_TELEGRAM = os.getenv("ENABLE_TELEGRAM", "false").lower() == "true"
TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID", "")

# ─── Database ────────────────────────────────────────────────────
DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "option_sell_pro.db")

# ─── Risk Limits ─────────────────────────────────────────────────
MAX_PORTFOLIO_DELTA = 0.3  # Max net delta exposure
MAX_PORTFOLIO_VEGA_ABS = 100  # Max absolute vega
DAILY_LOSS_LIMIT_PCT = 5.0  # Stop all trading if daily loss exceeds this %

# ─── Event Filter (avoid trading near these) ─────────────────────
# Format: (date_str, description)
EVENT_FILTER_BUFFER_DAYS = 2
