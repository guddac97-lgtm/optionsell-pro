"""
Recommendations Page - Main dashboard with daily trade picks
"""
import streamlit as st
from datetime import datetime
from typing import Dict, List

from data.nse_data import get_option_chain, fetch_spot_price
from analytics.scoring import score_recommendation
from analytics.greeks import (
    calculate_iv_rank, calculate_adx, get_trend_direction,
    fetch_historical_spot, days_to_expiry, time_to_expiry_years,
    black_scholes_greeks, get_risk_free_rate
)
from config import (
    INDICES, INDEX_DISPLAY, LOT_SIZE, MIN_SCORE, MAX_RECOMMENDATIONS,
    ENABLE_IRON_CONDOR, ENABLE_BULL_PUT_SPREAD, ENABLE_BEAR_CALL_SPREAD,
    ENABLE_SHORT_STRANGLE, CAPITAL
)
from strategies.iron_condor import find_iron_condor
from strategies.bull_put_spread import find_bull_put_spread
from strategies.bear_call_spread import find_bear_call_spread
from strategies.short_strangle import find_short_strangle
from utils.risk_manager import get_portfolio_risk_summary


def show_recommendations():
    """Main recommendations dashboard"""
    st.markdown("### 📊 Today's Recommendations")

    # Portfolio summary at top
    risk = get_portfolio_risk_summary()
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("Active Positions", risk["open_positions"])
    with col2:
        st.metric("Margin Used", f"₹{risk['total_margin_used']:,.0f}")
    with col3:
        st.metric("Deployed", f"{risk['deploy_pct']:.1f}%", delta=f"Max {10}%")
    with col4:
        st.metric("Current P&L", f"₹{risk['current_pnl']:,.0f}",
                  delta=f"{risk['positions_profitable']}W/{risk['positions_at_risk']}L")

    st.markdown("---")

    # Run analysis for each index
    recommendations = []

    for symbol in INDICES:
        with st.spinner(f"Analyzing {INDEX_DISPLAY[symbol]}..."):
            recs = _analyze_index(symbol)
            recommendations.extend(recs)

    # Sort by score, keep top N
    recommendations.sort(key=lambda x: x["score"], reverse=True)
    recommendations = recommendations[:MAX_RECOMMENDATIONS]

    if not recommendations:
        st.warning("No recommendations found today. Market conditions may not be favorable for option selling.")
        st.info("Try again tomorrow or check if NSE is open today.")
        return

    # Display recommendations
    for i, rec in enumerate(recommendations):
        _render_recommendation_card(rec, i + 1)


def _analyze_index(symbol: str) -> List[Dict]:
    """Analyze an index and generate strategy recommendations"""
    results = []

    # Fetch data
    spot = fetch_spot_price(symbol)
    if not spot:
        return results

    chain = get_option_chain(symbol)
    if not chain:
        return results

    # Historical data for scoring
    hist_prices = fetch_historical_spot(symbol, days=365)
    hist_prices_list = []
    if hist_prices is not None and not hist_prices.empty:
        hist_prices_list = [
            {"close": row["Close"], "high": row["High"], "low": row["Low"]}
            for _, row in hist_prices.iterrows()
        ]

    # Calculate historical IVs
    historical_ivs = _extract_historical_ivs(chain)

    # Calculate days to expiry
    dte = _get_next_expiry_days()

    # Run each strategy
    strategies = []
    if ENABLE_IRON_CONDOR:
        strategies.append(("Iron Condor", lambda: find_iron_condor(spot, chain, datetime.now(), target_delta=0.15)))
    if ENABLE_BULL_PUT_SPREAD:
        strategies.append(("Bull Put Spread", lambda: find_bull_put_spread(spot, chain, datetime.now(), target_otm_pct=0.03)))
    if ENABLE_BEAR_CALL_SPREAD:
        strategies.append(("Bear Call Spread", lambda: find_bear_call_spread(spot, chain, datetime.now(), target_otm_pct=0.03)))
    if ENABLE_SHORT_STRANGLE:
        strategies.append(("Short Strangle", lambda: find_short_strangle(spot, chain, datetime.now(), target_otm_pct=0.05)))

    for strategy_name, strategy_fn in strategies:
        setup = strategy_fn()
        if not setup:
            continue

        # Score the setup
        score_result = score_recommendation(
            index_name=symbol,
            strategy=strategy_name,
            spot_price=spot,
            strikes=setup.get("strikes", {}),
            option_chain=chain,
            historical_ivs=historical_ivs,
            historical_prices=hist_prices_list,
            days_to_exp=dte
        )

        if score_result["pass_filters"] and score_result["total_score"] >= MIN_SCORE:
            setup["score"] = score_result["total_score"]
            setup["index_name"] = symbol
            setup["index_display"] = INDEX_DISPLAY.get(symbol, symbol)
            setup["expiry_date"] = "Weekly" if dte <= 7 else "Monthly"
            setup["spot_price"] = spot
            setup["iv_rank"] = score_result.get("iv_rank", 0)
            setup["adx"] = score_result.get("adx", 0)
            setup["pcr"] = score_result.get("pcr", 0)
            setup["iv_environment"] = score_result.get("iv_environment", "NORMAL")
            setup["warnings"] = score_result.get("warnings", [])
            setup["date"] = datetime.now().strftime("%Y-%m-%d")
            results.append(setup)

    return results


def _extract_historical_ivs(chain: list) -> List[float]:
    """Extract IV values from option chain"""
    ivs = []
    for item in chain:
        iv = item.get("iv", 0)
        if iv > 0 and iv < 200:  # Sanity check: IV between 0-200%
            ivs.append(iv)
    return ivs if ivs else [15, 16, 14, 18, 17, 20, 22, 19, 15, 16]  # Fallback


def _get_next_expiry_days() -> int:
    """Get days to next expiry"""
    today = datetime.now()
    days_to_thursday = (3 - today.weekday()) % 7
    if days_to_thursday == 0 and today.hour >= 15:
        days_to_thursday = 7
    return max(1, days_to_thursday)


def _render_recommendation_card(rec: dict, rank: int):
    """Render a single recommendation card"""
    is_iron_condor = rec["strategy"] == "Iron Condor"
    is_profit = rec.get("max_profit", 0) > 0

    # Determine score color
    if rec["score"] >= 85:
        score_color = "#ffd700"
    elif rec["score"] >= 70:
        score_color = "#00c853"
    else:
        score_color = "#ff9800"

    st.markdown(f"""
    <div class="trade-card">
        <div class="top-bar">
            <div style="display: flex; align-items: center; gap: 10px;">
                <div style="
                    width: 40px; height: 40px; border-radius: 12px;
                    background: #1e1e3a; display: flex; align-items: center;
                    justify-content: center; font-size: 20px;
                ">{'🎯' if is_iron_condor else ('🐂' if 'Bull' in rec['strategy'] else '🐻')}</div>
                <div>
                    <div style="font-size: 16px; font-weight: 700; color: #fff;">{rec['strategy']}</div>
                    <div style="font-size: 12px; color: #888;">{rec.get('index_display', rec['index_name'])} • {rec.get('expiry_date', 'Weekly')} • ₹{rec.get('spot_price', 0):,.0f}</div>
                </div>
            </div>
            <div class="score-badge">
                <div class="score-value" style="color: {score_color};">{rec['score']}</div>
                <div class="score-label">Score</div>
            </div>
        </div>

        <div class="metric-row">
            <div class="metric-box">
                <div class="metric-val green">+₹{rec.get('expected_theta', 0):,.0f}/day</div>
                <div class="metric-lbl">Theta</div>
            </div>
            <div class="metric-box">
                <div class="metric-val green">₹{rec.get('max_profit', 0):,.0f}</div>
                <div class="metric-lbl">Max Profit</div>
            </div>
            <div class="metric-box">
                <div class="metric-val red">₹{rec.get('max_risk', 0):,.0f}</div>
                <div class="metric-lbl">Max Risk</div>
            </div>
        </div>

        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 6px; margin-bottom: 12px; font-size: 12px; color: #aaa;">
            <div>📐 IV Rank: <span style="color: #fff;">{rec.get('iv_rank', 0)}</span></div>
            <div>📈 ADX: <span style="color: #fff;">{rec.get('adx', 0)}</span></div>
            <div>📊 PCR: <span style="color: #fff;">{rec.get('pcr', 0)}</span></div>
            <div>⏱️ R:R: <span style="color: #fff;">{rec.get('risk_reward_ratio', 'N/A')}</span></div>
        </div>
    """, unsafe_allow_html=True)

    # Strikes info
    if is_iron_condor:
        st.markdown(f"""
        <div style="font-size: 12px; color: #888; margin-bottom: 12px;">
            🎯 Short Strikes → <strong style="color:#fff;">PE {rec['strikes']['short_put']:.0f}</strong> /
            <strong style="color:#fff;">CE {rec['strikes']['short_call']:.0f}</strong>
            &nbsp;|&nbsp; Wings → <strong style="color:#fff;">PE {rec['strikes']['long_put']:.0f}</strong> /
            <strong style="color:#fff;">CE {rec['strikes']['long_call']:.0f}</strong>
        </div>
        """, unsafe_allow_html=True)
    elif "Bull Put" in rec["strategy"]:
        st.markdown(f"""
        <div style="font-size: 12px; color: #888; margin-bottom: 12px;">
            🐂 Sell PE {rec['strikes']['short_put']:.0f} / Buy PE {rec['strikes']['long_put']:.0f}
        </div>
        """, unsafe_allow_html=True)
    elif "Bear Call" in rec["strategy"]:
        st.markdown(f"""
        <div style="font-size: 12px; color: #888; margin-bottom: 12px;">
            🐻 Sell CE {rec['strikes']['short_call']:.0f} / Buy CE {rec['strikes']['long_call']:.0f}
        </div>
        """, unsafe_allow_html=True)
    elif "Strangle" in rec["strategy"]:
        st.markdown(f"""
        <div style="font-size: 12px; color: #888; margin-bottom: 12px;">
            ⚡ Sell PE {rec['strikes']['short_put']:.0f} / Sell CE {rec['strikes']['short_call']:.0f}
        </div>
        """, unsafe_allow_html=True)

    # Warnings
    if rec.get("warnings"):
        for warning in rec["warnings"]:
            st.warning(f"⚠️ {warning}")

    # Execute button
    col_exec, col_view = st.columns([3, 1])
    with col_exec:
        if st.button(f"⚡ Execute", key=f"exec_{rec['strategy']}_{i}_{rank}", use_container_width=True, type="primary"):
            st.session_state[f"show_confirm_{rank}"] = True

    with col_view:
        if st.button("📋 View", key=f"view_{rank}", use_container_width=True):
            st.session_state[f"show_detail_{rank}"] = True

    # Confirmation dialog
    if st.session_state.get(f"show_confirm_{rank}"):
        _show_confirm_dialog(rec, rank)

    # Detail expander
    if st.session_state.get(f"show_detail_{rank}"):
        with st.expander("📊 Full Analysis", expanded=True):
            st.json(rec)

    st.markdown("</div>", unsafe_allow_html=True)


def _show_confirm_dialog(rec: dict, rank: int):
    """Show order confirmation dialog"""
    st.warning(f"⚡ **Confirm Trade: {rec['strategy']}**")

    col1, col2 = st.columns(2)
    with col1:
        st.write(f"**Index:** {rec.get('index_display', rec['index_name'])}")
        st.write(f"**Strategy:** {rec['strategy']}")
        st.write(f"**Score:** {rec['score']}/100")
    with col2:
        st.write(f"**Max Profit:** ₹{rec.get('max_profit', 0):,.0f}")
        st.write(f"**Max Risk:** ₹{rec.get('max_risk', 0):,.0f}")
        st.write(f"**Margin:** ₹{rec.get('margin', 0):,.0f}")

    st.write(f"**Strikes:** {rec.get('strikes', {})}")
    st.error(f"⚠️ This will place orders on Upstox. Max loss: ₹{rec.get('max_risk', 0):,.0f}. Confirm only if you understand the risk.")

    col_confirm, col_cancel = st.columns(2)
    with col_confirm:
        if st.button("✅ Confirm & Execute", key=f"confirm_{rank}", use_container_width=True, type="primary"):
            # Execute via order manager
            from execution.order_manager import execute_iron_condor, execute_spread
            if rec["strategy"] == "Iron Condor":
                result = execute_iron_condor(rec, confirm=True)
            else:
                strategy_type = "Bull Put Spread" if "Bull" in rec["strategy"] else "Bear Call Spread"
                result = execute_spread(rec, strategy_type, confirm=True)
            st.success(f"✅ Orders placed! {result.get('orders_placed', 0)} orders executed.")
            st.session_state[f"show_confirm_{rank}"] = False
            st.rerun()

    with col_cancel:
        if st.button("❌ Cancel", key=f"cancel_{rank}", use_container_width=True):
            st.session_state[f"show_confirm_{rank}"] = False
            st.rerun()
