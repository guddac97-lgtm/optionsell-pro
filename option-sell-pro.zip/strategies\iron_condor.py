"""
Iron Condor Strategy
Sell OTM Call + Buy further OTM Call + Sell OTM Put + Buy further OTM Put
Defined risk, defined reward, profits from time decay
"""
from typing import Dict, List, Optional
from analytics.greeks import (
    black_scholes_greeks, time_to_expiry_years, get_risk_free_rate
)
from config import LOT_SIZE


def find_iron_condor(
    spot_price: float,
    option_chain: list,
    expiry_date,
    target_delta: float = 0.15,
    wing_width: float = None
) -> Optional[Dict]:
    """
    Find optimal Iron Condor setup

    Args:
        spot_price: Current spot price
        option_chain: Parsed option chain data
        expiry_date: Expiry date
        target_delta: Target delta for short strikes (default 0.15 = ~15% OTM)
        wing_width: Width between short and long strikes (auto-calculated if None)

    Returns:
        Dict with condor setup or None if not found
    """
    chain_df = _prepare_chain(option_chain)
    if chain_df is None or len(chain_df) < 10:
        return None

    T = time_to_expiry_years(expiry_date)
    r = get_risk_free_rate()
    lot_size = LOT_SIZE.get("NIFTY", 50)

    # Separate CE and PE
    ce_df = chain_df[chain_df["type"] == "CE"].sort_values("strike")
    pe_df = chain_df[chain_df["type"] == "PE"].sort_values("strike")

    # Find short call strike (OTM, ~15 delta)
    short_call = _find_strike_by_delta(ce_df, spot_price, target_delta, "CE", T, r)
    if not short_call:
        return None

    # Find short put strike (OTM, ~-15 delta)
    short_put = _find_strike_by_delta(pe_df, spot_price, -target_delta, "PE", T, r)
    if not short_put:
        return None

    # Long strikes (wings)
    if wing_width is None:
        wing_width = max(spot_price * 0.02, 100)  # 2% of spot or 100 points

    long_call_strike = short_call["strike"] + wing_width
    long_put_strike = short_put["strike"] - wing_width

    # Find closest available strikes for wings
    long_call = _closest_strike(ce_df, long_call_strike)
    long_put = _closest_strike(pe_df, long_put_strike)

    if not long_call or not long_put:
        return None

    # Calculate premiums and risk/reward
    short_call_premium = short_call["ltp"]
    short_put_premium = short_put["ltp"]
    long_call_cost = long_call["ltp"]
    long_put_cost = long_put["ltp"]

    net_credit = (short_call_premium + short_put_premium) - (long_call_cost + long_put_cost)
    max_risk = wing_width * lot_size - net_credit
    max_profit = net_credit * lot_size
    margin = _estimate_margin(spot_price, short_put["strike"], short_call["strike"], max_risk)

    if max_risk <= 0 or net_credit <= 0:
        return None

    return {
        "strategy": "Iron Condor",
        "short_put_strike": short_put["strike"],
        "short_call_strike": short_call["strike"],
        "long_put_strike": long_put["strike"],
        "long_call_strike": long_call["strike"],
        "short_put_premium": round(short_put_premium, 2),
        "short_call_premium": round(short_call_premium, 2),
        "long_put_premium": round(long_put_premium, 2),
        "long_call_premium": round(long_call_cost, 2),
        "net_credit": round(net_credit, 2),
        "max_profit": round(max_profit, 2),
        "max_risk": round(max_risk, 2),
        "margin": round(margin, 2),
        "wing_width": wing_width,
        "expected_theta": round(
            (short_put.get("theta", 0) + short_call.get("theta", 0)) * lot_size, 2
        ),
        "risk_reward_ratio": round(max_risk / max_profit, 2) if max_profit > 0 else 999,
        "iv_avg": round(
            (short_put.get("iv", 0) + short_call.get("iv", 0)) / 2, 1
        ),
        "avg_delta": round(
            (short_put.get("delta", 0) + short_call.get("delta", 0)) / 2, 4
        ),
        "strikes": {
            "short_put": short_put["strike"],
            "long_put": long_put["strike"],
            "short_call": short_call["strike"],
            "long_call": long_call["strike"]
        }
    }


def _prepare_chain(option_chain: list):
    """Convert option chain list to DataFrame for easier processing"""
    import pandas as pd
    if not option_chain:
        return None
    df = pd.DataFrame(option_chain)
    if df.empty:
        return None
    # Clean numeric columns
    for col in ["ltp", "iv", "delta", "theta", "vega", "gamma", "oi", "bid", "ask"]:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0)
    return df


def _find_strike_by_delta(df, spot: float, target_delta: float,
                          option_type: str, T: float, r: float):
    """Find the strike whose delta is closest to target"""
    if df.empty:
        return None

    best = None
    min_diff = float("inf")

    for _, row in df.iterrows():
        if row["ltp"] <= 0 or row.get("delta", 0) == 0:
            continue

        sigma = row.get("iv", 20) / 100
        if sigma <= 0.01:
            sigma = 0.20

        greeks = black_scholes_greeks(spot, row["strike"], T, r, sigma, option_type)
        delta = greeks["delta"]

        if option_type == "PE":
            delta = abs(delta)
        else:
            delta = abs(delta)

        diff = abs(delta - abs(target_delta))
        if diff < min_diff and row["oi"] > 1000:
            min_diff = diff
            best = row.to_dict()

    return best


def _closest_strike(df, target_strike: float) -> Optional[dict]:
    """Find the closest available strike in the chain"""
    if df.empty:
        return None

    df_sorted = df.sort_values("strike")
    best = None
    min_diff = float("inf")

    for _, row in df_sorted.iterrows():
        if row["ltp"] > 0:
            diff = abs(row["strike"] - target_strike)
            if diff < min_diff:
                min_diff = diff
                best = row.to_dict()

    return best


def _estimate_margin(spot: float, short_put: float, short_call: float, max_risk: float) -> float:
    """Estimate margin requirement (simplified)"""
    # Simplified SPAN margin estimate
    # In production, use actual SPAN calculator from broker
    base_margin = max_risk * 1.5  # 1.5x max risk as margin
    return round(base_margin, 0)
