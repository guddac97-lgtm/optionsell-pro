"""
Multi-Factor Scoring Engine for Option Selling Recommendations
Each factor is weighted, combined into 0-100 score
"""
from typing import Dict, Any
from analytics.greeks import (
    calculate_iv_rank, calculate_iv_percentile, classify_iv_environment,
    calculate_adx, get_trend_direction, calculate_pcr, interpret_pcr,
    days_to_expiry, time_to_expiry_years, get_risk_free_rate
)
from config import (
    WEIGHT_IV_RANK, WEIGHT_TREND, WEIGHT_DISTANCE_SR,
    WEIGHT_DTE, WEIGHT_PCR, WEIGHT_OI_CONCENTRATION,
    WEIGHT_LIQUIDITY, WEIGHT_EVENT_FILTER,
    MIN_IV_RANK, MIN_DTE, MAX_DTE, MIN_OI
)


# ─── Scoring Engine ──────────────────────────────────────────────
def score_recommendation(
    index_name: str,
    strategy: str,
    spot_price: float,
    strikes: dict,
    option_chain: list,
    historical_ivs: list,
    historical_prices: list,
    days_to_exp: int
) -> Dict[str, Any]:
    """
    Score a potential trade setup on 0-100 scale

    Returns dict with:
        - total_score: 0-100
        - factor_scores: breakdown per factor
        - pass_filters: bool (all hard filters passed?)
        - warnings: list of warning strings
    """
    factor_scores = {}
    warnings = []
    pass_filters = True

    # ═══ HARD FILTERS ═══
    if days_to_exp < MIN_DTE or days_to_exp > MAX_DTE:
        pass_filters = False
        factor_scores["dte"] = 0
        return {"total_score": 0, "factor_scores": factor_scores, "pass_filters": False, "warnings": ["DTE out of range"]}

    # ═══ Factor 1: IV Rank (weight: 25%) ═══
    iv_rank = calculate_iv_rank(strikes.get("avg_iv", 20), historical_ivs)
    if iv_rank >= 70:
        iv_score = 100  # High IV = best for selling
    elif iv_rank >= 50:
        iv_score = 85
    elif iv_rank >= 35:
        iv_score = 65
    elif iv_rank >= MIN_IV_RANK:
        iv_score = 40
    else:
        iv_score = 10
        pass_filters = False
        warnings.append(f"IV Rank too low: {iv_rank}")
    factor_scores["iv_rank"] = {"score": iv_score, "weight": WEIGHT_IV_RANK, "raw": iv_rank}

    # ═══ Factor 2: Trend Strength (weight: 15%) ═══
    highs = [p.get("high", 0) for p in historical_prices[-30:]]
    lows = [p.get("low", 0) for p in historical_prices[-30:]]
    closes = [p.get("close", 0) for p in historical_prices[-30:]]

    adx = calculate_adx(highs, lows, closes)
    if adx >= 30:
        trend_score = 100  # Strong trend = good for directional spreads
    elif adx >= 25:
        trend_score = 80
    elif adx >= 20:
        trend_score = 60
    else:
        trend_score = 30  # Sideways = good for iron condor but lower score

    factor_scores["trend"] = {"score": trend_score, "weight": WEIGHT_TREND, "raw": adx}

    # ═══ Factor 3: Distance from Support/Resistance (weight: 15%) ═══
    sr_score = _calculate_sr_distance_score(spot_price, strikes, historical_prices)
    factor_scores["distance_sr"] = {"score": sr_score, "weight": WEIGHT_DISTANCE_SR, "raw": sr_score}

    # ═══ Factor 4: Days to Expiry (weight: 15%) ═══
    # Sweet spot: 7-14 days
    if 7 <= days_to_exp <= 14:
        dte_score = 100
    elif 3 <= days_to_exp < 7:
        dte_score = 75
    elif 15 <= days_to_exp <= 21:
        dte_score = 85
    else:
        dte_score = 50
    factor_scores["dte"] = {"score": dte_score, "weight": WEIGHT_DTE, "raw": days_to_exp}

    # ═══ Factor 5: PCR (Put-Call Ratio) (weight: 10%) ═══
    # Need OI data from option chain
    call_oi = sum(item["oi"] for item in option_chain if item["type"] == "CE" and item.get("oi", 0) > 0)
    put_oi = sum(item["oi"] for item in option_chain if item["type"] == "PE" and item.get("oi", 0) > 0)

    if call_oi > 0:
        pcr = calculate_pcr(put_oi, call_oi)
        pcr_interpretation = interpret_pcr(pcr)

        # For selling: moderate PCR is best (not too extreme)
        if 0.7 <= pcr <= 1.3:
            pcr_score = 100  # Balanced sentiment
        elif 0.5 <= pcr < 0.7 or 1.3 < pcr <= 1.8:
            pcr_score = 70
        else:
            pcr_score = 40  # Extreme sentiment = higher risk
    else:
        pcr = 1.0
        pcr_score = 50
        pcr_interpretation = "UNKNOWN"

    factor_scores["pcr"] = {"score": pcr_score, "weight": WEIGHT_PCR, "raw": pcr}

    # ═══ Factor 6: OI Concentration (weight: 10%) ═══
    oi_score = _calculate_oi_concentration_score(strikes, option_chain)
    factor_scores["oi_concentration"] = {"score": oi_score, "weight": WEIGHT_OI_CONCENTRATION, "raw": oi_score}

    # ═══ Factor 7: Liquidity (weight: 5%) ═══
    liquidity_score = _calculate_liquidity_score(strikes, option_chain)
    if liquidity_score < 30:
        pass_filters = False
        warnings.append("Low liquidity in strikes")
    factor_scores["liquidity"] = {"score": liquidity_score, "weight": WEIGHT_LIQUIDITY, "raw": liquidity_score}

    # ═══ Factor 8: Event Filter (weight: 5%) ═══
    event_score = _check_event_filter()
    if event_score < 50:
        warnings.append("Near major event - reduced score")
    factor_scores["event_filter"] = {"score": event_score, "weight": WEIGHT_EVENT_FILTER, "raw": event_score}

    # ═══ Calculate Weighted Total Score ═══
    total_weighted_score = 0
    total_weight = 0

    for factor, data in factor_scores.items():
        total_weighted_score += data["score"] * data["weight"]
        total_weight += data["weight"]

    final_score = int(total_weighted_score / total_weight) if total_weight > 0 else 0

    return {
        "total_score": final_score,
        "factor_scores": factor_scores,
        "pass_filters": pass_filters,
        "warnings": warnings,
        "iv_rank": iv_rank,
        "adx": adx,
        "pcr": pcr,
        "iv_environment": classify_iv_environment(iv_rank),
        "trend_direction": get_trend_direction(closes) if closes else "UNKNOWN"
    }


# ─── Helper Functions ────────────────────────────────────────────
def _calculate_sr_distance_score(spot: float, strikes: dict, price_history: list) -> int:
    """Score based on distance of short strikes from support/resistance levels"""
    if not price_history or len(price_history) < 20:
        return 50

    # Simple S/R: recent 20-period high/low
    recent_high = max(p["high"] for p in price_history[-20:])
    recent_low = min(p["low"] for p in price_history[-20:])
    range_width = recent_high - recent_low

    if range_width == 0:
        return 50

    # Check how far our short strikes are from these levels
    short_put = strikes.get("short_put", 0)
    short_call = strikes.get("short_call", 0)

    # Distance as % of range
    call_distance = (short_call - spot) / range_width if short_call > 0 else 0
    put_distance = (spot - short_put) / range_width if short_put > 0 else 0

    # Optimal: strikes ~5-15% away from spot in range terms
    if 0.05 <= call_distance <= 0.20 and 0.05 <= put_distance <= 0.20:
        return 100
    elif 0.03 <= call_distance <= 0.25 and 0.03 <= put_distance <= 0.25:
        return 70
    else:
        return 40  # Too close or too far


def _calculate_oi_concentration_score(strikes: dict, option_chain: list) -> int:
    """Score based on OI concentration at our strikes vs others"""
    if not option_chain:
        return 50

    # Get OI at our short strikes
    short_put = strikes.get("short_put", 0)
    short_call = strikes.get("short_call", 0)

    short_pe_oi = _get_oi_at_strike(option_chain, short_put, "PE")
    short_ce_oi = _get_oi_at_strike(option_chain, short_call, "CE")

    # Get max OI across all strikes
    all_pe_oi = [item["oi"] for item in option_chain if item["type"] == "PE"]
    all_ce_oi = [item["oi"] for item in option_chain if item["type"] == "CE"]
    max_pe_oi = max(all_pe_oi) if all_pe_oi else 1
    max_ce_oi = max(all_ce_oi) if all_ce_oi else 1

    # Score: our strikes should have decent OI (not too low, not max which = resistance)
    pe_ratio = short_pe_oi / max_pe_oi if max_pe_oi > 0 else 0
    ce_ratio = short_ce_oi / max_ce_oi if max_ce_oi > 0 else 0

    avg_ratio = (pe_ratio + ce_ratio) / 2
    if 0.3 <= avg_ratio <= 0.7:
        return 100  # Good OI but not max (not sitting on wall)
    elif 0.1 <= avg_ratio <= 0.9:
        return 70
    else:
        return 40


def _get_oi_at_strike(option_chain: list, strike: float, option_type: str) -> int:
    """Get OI at a specific strike price"""
    for item in option_chain:
        if item["strike"] == strike and item["type"] == option_type:
            return item.get("oi", 0)
    return 0


def _calculate_liquidity_score(strikes: dict, option_chain: list) -> int:
    """Score based on bid-ask spread and OI at our strikes"""
    from config import MIN_OI

    short_put = strikes.get("short_put", 0)
    short_call = strikes.get("short_call", 0)

    total_score = 0
    count = 0

    for strike, opt_type in [(short_put, "PE"), (short_call, "CE")]:
        for item in option_chain:
            if item["strike"] == strike and item["type"] == opt_type:
                oi = item.get("oi", 0)
                bid = item.get("bid", 0)
                ask = item.get("ask", 0)
                ltp = item.get("ltp", 0)

                # OI check
                oi_score = 100 if oi >= MIN_OI * 2 else (60 if oi >= MIN_OI else 0)

                # Spread check (bid-ask tightness)
                if ltp > 0:
                    spread_pct = (ask - bid) / ltp * 100
                    spread_score = 100 if spread_pct <= 2 else (60 if spread_pct <= 5 else 0)
                else:
                    spread_score = 0

                total_score += (oi_score + spread_score) / 2
                count += 1
                break

    return int(total_score / count) if count > 0 else 0


def _check_event_filter() -> int:
    """Check if any major event is near (reduces score)"""
    from datetime import datetime, timedelta
    from config import EVENT_FILTER_BUFFER_DAYS

    # Known NSE event calendar (approximate dates, can be updated)
    events_2026 = [
        # (date, name, impact)
        ("2026-01-26", "Republic Day", 1),
        ("2026-03-20", "RBI Policy", 3),
        ("2026-04-14", "Mahavir Jayanti", 1),
        ("2026-05-01", "Labour Day", 1),
        ("2026-08-15", "Independence Day", 1),
        ("2026-10-02", "Gandhi Jayanti", 1),
        ("2026-10-20", "RBI Policy", 3),
        ("2026-12-25", "Christmas", 1),
    ]

    today = datetime.now()
    buffer = timedelta(days=EVENT_FILTER_BUFFER_DAYS)

    for event_date_str, name, impact in events_2026:
        event_date = datetime.strptime(event_date_str, "%Y-%m-%d")
        if abs((event_date - today).days) <= EVENT_FILTER_BUFFER_DAYS + 1:
            # Event near — reduce score
            return max(0, 100 - impact * 25)

    return 100
