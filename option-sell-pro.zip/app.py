"""
OptionSell Pro - NSE Option Selling Recommendation Tool
Zero Cost • Live Data • Mobile First • Built with Streamlit + Upstox API
"""
import streamlit as st
import sys
import os

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Initialize database
from database.db import init_db
init_db()

# Page config
st.set_page_config(
    page_title="OptionSell Pro",
    page_icon="🎯",
    layout="wide",
    initial_sidebar_state="collapsed"
)

# Custom CSS - Mobile First
st.markdown("""
<style>
/* Base Reset */
* { margin: 0; padding: 0; box-sizing: border-box; }

/* Hide Streamlit default elements */
#MainMenu, header, footer, .stDeployButton { display: none !important; }
.stApp { background: #0f0f1a !important; }

/* Mobile viewport */
@media (max-width: 768px) {
    .main .block-container { padding: 0.5rem !important; }
    .stColumns > div { min-width: 100% !important; }
}

/* Card Styles */
.trade-card {
    background: #1a1a2e;
    border-radius: 16px;
    padding: 16px;
    margin-bottom: 12px;
    border: 1px solid #2a2a4a;
}
.trade-card .top-bar {
    display: flex; justify-content: space-between; align-items: center;
}
.score-badge {
    background: #1e1e3a;
    border-radius: 12px;
    padding: 8px 16px;
    text-align: center;
}
.score-value {
    font-size: 24px; font-weight: 800; color: #ffd700;
}
.score-label {
    font-size: 11px; color: #888;
}
.metric-row {
    display: grid; grid-template-columns: 1fr 1fr 1fr;
    gap: 8px; margin: 12px 0;
}
.metric-box {
    background: #1e1e3a; border-radius: 10px; padding: 10px;
    text-align: center;
}
.metric-val { font-size: 14px; font-weight: 700; color: #fff; }
.metric-val.green { color: #00c853; }
.metric-val.red { color: #e94560; }
.metric-lbl { font-size: 10px; color: #888; margin-top: 2px; }

/* Profit/Loss Colors */
.profit { color: #00c853; }
.loss { color: #e94560; }
.neutral { color: #ff9800; }

/* Execute Button */
.btn-execute {
    background: linear-gradient(135deg, #e94560, #c23152);
    color: white; border: none; border-radius: 10px;
    padding: 10px 24px; font-size: 14px; font-weight: 700;
    cursor: pointer; width: 100%;
}
.btn-execute:hover { opacity: 0.9; }
.btn-secondary {
    background: transparent; color: #aaa;
    border: 1px solid #3a3a5a; border-radius: 10px;
    padding: 10px 16px; font-size: 13px;
}
.btn-danger {
    background: #e94560; color: white;
    border: none; border-radius: 10px;
    padding: 10px 16px; font-size: 13px; font-weight: 600;
}

/* Disclaimer */
.disclaimer {
    background: #1e1e3a; border-radius: 12px;
    padding: 14px 16px; margin-top: 16px;
    border: 1px solid #3a3a5a;
}
.disclaimer-text {
    font-size: 11px; color: #666; line-height: 1.6;
}

/* Responsive table */
.dataframe { font-size: 12px; }
</style>
""", unsafe_allow_html=True)

# ─── App Header ──────────────────────────────────────────────────
def render_header():
    st.markdown("""
    <div style="
        background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
        padding: 16px 20px; border-radius: 16px; margin-bottom: 20px;
        border: 1px solid #2a2a4a; display: flex; justify-content: space-between; align-items: center;
    ">
        <div style="display: flex; align-items: center; gap: 12px;">
            <div style="
                width: 40px; height: 40px;
                background: linear-gradient(135deg, #e94560, #c23152);
                border-radius: 12px; display: flex; align-items: center; justify-content: center;
                font-size: 18px; font-weight: bold; color: white;
            ">OS</div>
            <div>
                <div style="font-size: 18px; font-weight: 700; color: #fff;">OptionSell Pro</div>
                <div style="font-size: 12px; color: #888;">Smart Option Selling</div>
            </div>
        </div>
        <div style="font-size: 13px; color: #00c853; font-weight: 600;">
            🟢 Live
        </div>
    </div>
    """, unsafe_allow_html=True)


# ─── Navigation ──────────────────────────────────────────────────
def render_nav(active_tab: str):
    tabs = {
        "Recommendations": "📊",
        "Positions": "📂",
        "Journal": "📔",
        "Backtest": "🧪",
        "Settings": "⚙️"
    }

    cols = st.columns(5)
    for i, (tab_name, icon) in enumerate(tabs.items()):
        with cols[i]:
            is_active = active_tab == tab_name
            if st.button(
                f"{icon} {tab_name.split()[0]}",
                key=f"nav_{tab_name}",
                use_container_width=True,
                type="primary" if is_active else "secondary"
            ):
                st.session_state.active_tab = tab_name
                st.rerun()


# ─── Disclaimer ──────────────────────────────────────────────────
def render_disclaimer():
    st.markdown("""
    <div class="disclaimer">
        <div class="disclaimer-text">
            <strong>⚠️ Disclaimer:</strong> This tool provides educational recommendations only.
            Not SEBI registered research. Options trading involves significant risk of loss.
            Past performance ≠ future returns. Trade at your own risk.
        </div>
    </div>
    """, unsafe_allow_html=True)


# ─── Main App Router ─────────────────────────────────────────────
def main():
    # Session state
    if "active_tab" not in st.session_state:
        st.session_state.active_tab = "Recommendations"

    render_header()
    render_nav(st.session_state.active_tab)

    tab = st.session_state.active_tab

    if tab == "Recommendations":
        from pages.page_recommendations import show_recommendations
        show_recommendations()
    elif tab == "Positions":
        from pages.page_positions import show_positions
        show_positions()
    elif tab == "Journal":
        from pages.page_journal import show_journal
        show_journal()
    elif tab == "Backtest":
        from pages.page_backtest import show_backtest
        show_backtest()
    elif tab == "Settings":
        from pages.page_settings import show_settings
        show_settings()

    render_disclaimer()


if __name__ == "__main__":
    main()
