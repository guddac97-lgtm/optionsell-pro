"""
Order Manager - Handles order placement via Upstox API
"""
import json
from typing import Dict, List
from datetime import datetime
from database.db import save_position, mark_recommendation_executed
from execution.upstox_api import get_upstox


# ─── Order Placement ─────────────────────────────────────────────
def execute_iron_condor(rec: dict, confirm: bool = False) -> Dict:
    """
    Execute Iron Condor: 4 orders
    1. Sell CE (short call)
    2. Buy CE (long call)
    3. Sell PE (short put)
    4. Buy PE (long put)
    """
    upstox = get_upstox()
    results = []

    orders = [
        # Short Call (SELL)
        {
            "quantity": 1,
            "product": "D",
            "validity": "DAY",
            "price": rec["short_call_premium"],
            "instrument_token": _get_instrument_key(rec["index_name"], rec["short_call_strike"], "CE", rec["expiry_date"]),
            "order_type": "LIMIT",
            "transaction_type": "SELL",
            "disclosed_quantity": 0,
            "trigger_price": 0,
            "is_amo": False
        },
        # Long Call (BUY)
        {
            "quantity": 1,
            "product": "D",
            "validity": "DAY",
            "price": rec["long_call_premium"],
            "instrument_token": _get_instrument_key(rec["index_name"], rec["long_call_strike"], "CE", rec["expiry_date"]),
            "order_type": "LIMIT",
            "transaction_type": "BUY",
            "disclosed_quantity": 0,
            "trigger_price": 0,
            "is_amo": False
        },
        # Short Put (SELL)
        {
            "quantity": 1,
            "product": "D",
            "validity": "DAY",
            "price": rec["short_put_premium"],
            "instrument_token": _get_instrument_key(rec["index_name"], rec["short_put_strike"], "PE", rec["expiry_date"]),
            "order_type": "LIMIT",
            "transaction_type": "SELL",
            "disclosed_quantity": 0,
            "trigger_price": 0,
            "is_amo": False
        },
        # Long Put (BUY)
        {
            "quantity": 1,
            "product": "D",
            "validity": "DAY",
            "price": rec["long_put_premium"],
            "instrument_token": _get_instrument_key(rec["index_name"], rec["long_put_strike"], "PE", rec["expiry_date"]),
            "order_type": "LIMIT",
            "transaction_type": "BUY",
            "disclosed_quantity": 0,
            "trigger_price": 0,
            "is_amo": False
        }
    ]

    if confirm:
        for order in orders:
            result = upstox.place_order(order)
            results.append(result)

    # Save position to database
    if confirm and results:
        order_ids = [r.get("data", {}).get("order_id", "") for r in results if "data" in r]
        position_id = save_position({
            "strategy": "Iron Condor",
            "index_name": rec["index_name"],
            "expiry_date": rec["expiry_date"],
            "strikes": rec["strikes"],
            "entry_premium": rec["net_credit"],
            "max_profit": rec["max_profit"],
            "max_risk": rec["max_risk"],
            "margin_used": rec.get("margin", 0),
            "score": rec.get("score", 0),
            "upstox_order_ids": order_ids
        })
        mark_recommendation_executed(rec["id"])

    return {
        "orders_placed": len(results),
        "results": results,
        "status": "SUCCESS" if all("data" in r for r in results) else "PARTIAL"
    }


def execute_spread(rec: dict, strategy_type: str, confirm: bool = False) -> Dict:
    """Execute Bull Put or Bear Call Spread (2 orders each)"""
    upstox = get_upstox()

    if strategy_type == "Bull Put Spread":
        orders = [
            {
                "quantity": 1, "product": "D", "validity": "DAY",
                "price": rec["short_put_premium"],
                "instrument_token": _get_instrument_key(rec["index_name"], rec["short_put_strike"], "PE", rec["expiry_date"]),
                "order_type": "LIMIT", "transaction_type": "SELL",
                "disclosed_quantity": 0, "trigger_price": 0, "is_amo": False
            },
            {
                "quantity": 1, "product": "D", "validity": "DAY",
                "price": rec["long_put_premium"],
                "instrument_token": _get_instrument_key(rec["index_name"], rec["long_put_strike"], "PE", rec["expiry_date"]),
                "order_type": "LIMIT", "transaction_type": "BUY",
                "disclosed_quantity": 0, "trigger_price": 0, "is_amo": False
            }
        ]
    elif strategy_type == "Bear Call Spread":
        orders = [
            {
                "quantity": 1, "product": "D", "validity": "DAY",
                "price": rec["short_call_premium"],
                "instrument_token": _get_instrument_key(rec["index_name"], rec["short_call_strike"], "CE", rec["expiry_date"]),
                "order_type": "LIMIT", "transaction_type": "SELL",
                "disclosed_quantity": 0, "trigger_price": 0, "is_amo": False
            },
            {
                "quantity": 1, "product": "D", "validity": "DAY",
                "price": rec["long_call_premium"],
                "instrument_token": _get_instrument_key(rec["index_name"], rec["long_call_strike"], "CE", rec["expiry_date"]),
                "order_type": "LIMIT", "transaction_type": "BUY",
                "disclosed_quantity": 0, "trigger_price": 0, "is_amo": False
            }
        ]
    else:
        return {"status": "ERROR", "message": "Unknown strategy"}

    results = []
    if confirm:
        for order in orders:
            result = upstox.place_order(order)
            results.append(result)

    if confirm and results:
        order_ids = [r.get("data", {}).get("order_id", "") for r in results if "data" in r]
        save_position({
            "strategy": strategy_type,
            "index_name": rec["index_name"],
            "expiry_date": rec["expiry_date"],
            "strikes": rec["strikes"],
            "entry_premium": rec["net_credit"],
            "max_profit": rec["max_profit"],
            "max_risk": rec["max_risk"],
            "margin_used": rec.get("margin", 0),
            "score": rec.get("score", 0),
            "upstox_order_ids": order_ids
        })
        mark_recommendation_executed(rec["id"])

    return {
        "orders_placed": len(results),
        "results": results,
        "status": "SUCCESS" if all("data" in r for r in results) else "PARTIAL"
    }


def _get_instrument_key(index_name: str, strike: float, option_type: str, expiry: str) -> str:
    """Generate Upstox instrument key"""
    # Format: NSE_FO|XXXXXCE/PE-DDMMMYY
    if isinstance(expiry, str):
        exp = datetime.strptime(expiry, "%Y-%m-%d").strftime("%d%b%y").upper()
    else:
        exp = expiry.strftime("%d%b%y").upper()

    symbol = f"{int(strike)}{option_type}"
    return f"NSE_FO|{index_name}{symbol}{exp}"


def get_open_positions_from_upstox() -> List[Dict]:
    """Fetch open positions from Upstox"""
    upstox = get_upstox()
    result = upstox.get_positions()
    if "data" in result:
        return result["data"]
    return []
