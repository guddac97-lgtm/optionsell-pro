"""
Short Strangle Strategy
Sell OTM Call + Sell OTM Put (uncovered)
Higher risk - enable only with experience, requires higher margin
"""
from typing import Dict, Optional
import pandas as pd
from config import LOT_SIZE


def find_short_strangle(
    spot_price: float,
    option_chain: list,
    expiry_date,
    target_otm_pct: float = 0.05  # 5% OTM (wider than iron condor)
) -> Optional[Dict]:
    """Find Short Strangle setup (high margin, high risk)"""
    chain_df = _prepare_chain(option_chain)
    if chain_df is None or len(chain_df) < 5:
        return None

    ce_df = chain_df[chain_df["type"] == "CE"].sort_values("strike")
    pe_df = chain_df[chain_df["type"] == "PE"].sort_values("strike")

    # Sell OTM Call 5% above spot
    short_call_strike = spot_price * (1 + target_otm_pct)
    short_call = _closest_strike(ce_df, short_call_strike)
    if not short_call or short_call["ltp"] <= 0:
        return None

    # Sell OTM Put 5% below spot
    short_put_strike = spot_price * (1 - target_otm_pct)
    short_put = _closest_strike(pe_df, short_put_strike)
    if not short_put or short_put["ltp"] <= 0:
        return None

    lot_size = LOT_SIZE.get("BANKNIFTY", 15)
    net_credit = (short_call["ltp"] + short_put["ltp"]) * lot_size
    max_profit = net_credit
    margin = _estimate_strangle_margin(spot_price, short_put["strike"], short_call["strike"])

    # Theoretical max loss = unlimited but for stress testing use VaR
    var_loss = _calculate_var_loss(spot_price, short_put["strike"], short_call["strike"], lot_size)
    max_risk = var_loss

    return {
        "strategy": "Short Strangle",
        "short_call_strike": short_call["strike"],
        "short_put_strike": short_put["strike"],
        "short_call_premium": round(short_call["ltp"], 2),
        "short_put_premium": round(short_put["ltp"], 2),
        "net_credit": round(short_call["ltp"] + short_put["ltp"], 2),
        "max_profit": round(max_profit, 2),
        "max_risk": round(max_risk, 2),
        "margin": round(margin, 2),
        "expected_theta": round(
            (short_call.get("theta", 0) + short_put.get("theta", 0)) * lot_size, 2
        ),
        "risk_reward_ratio": round(max_risk / max_profit, 2) if max_profit > 0 else 999,
        "warning": "UNDEFINED RISK - Adjust at 50% of credit or use stop loss",
        "iv_short": round(
            (short_call.get("iv", 0) + short_put.get("iv", 0)) / 2, 1
        ),
        "strikes": {
            "short_put": short_put["strike"],
            "short_call": short_call["strike"]
        }
    }


def _prepare_chain(option_chain: list):
    if not option_chain:
        return None
    df = pd.DataFrame(option_chain)
    if df.empty:
        return None
    for col in ["ltp", "iv", "delta", "theta", "oi", "bid", "ask"]:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0)
    return df


def _closest_strike(df, target_strike: float) -> Optional[dict]:
    if df.empty:
        return None
    best = None
    min_diff = float("inf")
    for _, row in df.iterrows():
        if row["ltp"] > 0 and row.get("oi", 0) > 500:
            diff = abs(row["strike"] - target_strike)
            if diff < min_diff:
                min_diff = diff
                best = row.to_dict()
    return best


def _estimate_strangle_margin(spot: float, short_put: float, short_call: float) -> float:
    """Estimate margin (SPAN-like calculation)"""
    # Use 2x of one side as margin approximation
    side_margin = abs(spot - short_put) * 1.5 * 15
    return round(side_margin, 0)


def _calculate_var_loss(spot: float, short_put: float, short_call: float, lot_size: int) -> float:
    """Calculate worst-case loss (using VaR at 99% confidence)"""
    # For short strangle, theoretical max loss is unlimited
    # Use VaR-based estimate: 3 standard deviations move
    move = spot * 0.05  # ~5% expected move
    if (spot - short_put) > (short_call - spot):
        # Put side has more risk
        var_loss = (move + (spot - short_put)) * lot_size
    else:
        var_loss = (move + (short_call - spot)) * lot_size
    return round(var_loss, 0)