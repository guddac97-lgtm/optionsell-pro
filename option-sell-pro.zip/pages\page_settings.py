"""
Settings Page - App configuration and preferences
"""
import streamlit as st
from config import (
    CAPITAL, MAX_RISK_PER_TRADE_PCT, MAX_PORTFOLIO_DEPLOY_PCT,
    MIN_IV_RANK, MAX_DTE, MIN_OI, MIN_SCORE,
    ENABLE_IRON_CONDOR, ENABLE_BULL_PUT_SPREAD, ENABLE_BEAR_CALL_SPREAD,
    ENABLE_SHORT_STRANGLE, ENABLE_NAKED_OPTIONS, ENABLE_TELEGRAM,
    UPSTOX_API_KEY, UPSTOX_ACCESS_TOKEN
)


def show_settings():
    """Settings page"""
    st.markdown("### ⚙️ Settings")

    # ─── API Status ──────────────────────────────────────────────
    st.markdown("#### 🔗 Connection Status")
    col1, col2 = st.columns(2)
    with col1:
        if UPSTOX_API_KEY:
            st.success("✅ Upstox API: Connected")
        else:
            st.error("❌ Upstox API: Not connected")
            st.info("Add your API keys to .env file")
    with col2:
        if ENABLE_TELEGRAM:
            st.success("✅ Telegram: Enabled")
        else:
            st.warning("⚪ Telegram: Disabled")

    st.markdown("---")

    # ─── Trading Parameters ──────────────────────────────────────
    st.markdown("#### 💼 Trading Parameters")

    col1, col2 = st.columns(2)
    with col1:
        new_capital = st.number_input("Total Capital (₹)", value=CAPITAL, min_value=10000, step=10000)
        new_max_risk = st.slider("Max Risk per Trade (%)", 0.5, 5.0, MAX_RISK_PER_TRADE_PCT, 0.25)
        new_max_deploy = st.slider("Max Portfolio Deploy (%)", 5, 50, MAX_PORTFOLIO_DEPLOY_PCT, 5)

    with col2:
        new_min_iv = st.slider("Min IV Rank", 0, 100, MIN_IV_RANK, 5)
        new_max_dte = st.slider("Max DTE", 7, 45, MAX_DTE, 1)
        new_min_oi = st.number_input("Min Open Interest", value=MIN_OI, min_value=100, step=100)

    # Save button
    if st.button("💾 Save Settings", use_container_width=True, type="primary"):
        st.success("✅ Settings saved! (Note: .env file needs to be updated for permanent changes)")
        st.info("For permanent changes, edit the .env file or config.py directly.")

    st.markdown("---")

    # ─── Strategy Toggles ────────────────────────────────────────
    st.markdown("#### 🎯 Strategy Toggles")

    col1, col2 = st.columns(2)
    with col1:
        ic = st.checkbox("Iron Condor", value=ENABLE_IRON_CONDOR)
        bps = st.checkbox("Bull Put Spread", value=ENABLE_BULL_PUT_SPREAD)
    with col2:
        bcs = st.checkbox("Bear Call Spread", value=ENABLE_BEAR_CALL_SPREAD)
        ss = st.checkbox("Short Strangle (High Risk)", value=ENABLE_SHORT_STRANGLE)

    st.warning("⚠️ Short Strangle carries undefined risk. Only enable if experienced.")

    st.markdown("---")

    # ─── Telegram Settings ───────────────────────────────────────
    st.markdown("#### 🔔 Telegram Alerts")
    telegram_enabled = st.checkbox("Enable Telegram Alerts", value=ENABLE_TELEGRAM)

    if telegram_enabled:
        bot_token = st.text_input("Bot Token", type="password", placeholder="123456:ABC-DEF...")
        chat_id = st.text_input("Chat ID", placeholder="Your Telegram user ID")

        if st.button("🔗 Connect Telegram"):
            if bot_token and chat_id:
                st.success("✅ Telegram connected! You'll receive alerts for:")
                st.write("• Daily recommendations")
                st.write("• Position profit/loss alerts")
                st.write("• Stop loss triggers")
            else:
                st.error("Please enter both Bot Token and Chat ID")

    st.markdown("---")

    # ─── Advanced ────────────────────────────────────────────────
    st.markdown("#### 🔧 Advanced")

    with st.expander("Risk Management Rules"):
        st.write("""
        **Hard Rules (non-negotiable):**
        - Max 2% risk per trade
        - Max 10% portfolio deployment
        - Stop loss at 2x premium collected
        - Book 50% profit when achieved
        - Close all positions 3 days before expiry
        - No trading 2 days before major events
        """)

    with st.expander("Scoring Model Weights"):
        st.write("""
        | Factor | Weight |
        |---|---|
        | IV Rank | 25% |
        | Trend Strength (ADX) | 15% |
        | Distance from S/R | 15% |
        | Days to Expiry | 15% |
        | PCR (Put-Call Ratio) | 10% |
        | OI Concentration | 10% |
        | Liquidity | 5% |
        | Event Filter | 5% |
        """)

    with st.expander("Data Sources"):
        st.write("""
        **Primary:** NSE Website (live, free)
        **Secondary:** NSEpy library (historical + backup)
        **Execution:** Upstox API v2 (free with trading account)
        """)

    st.markdown("---")

    # ─── About ───────────────────────────────────────────────────
    st.markdown("#### ℹ️ About")
    st.markdown("""
    **OptionSell Pro v1.0**
    Zero Cost • Live Data • Mobile First

    Built with Python + Streamlit + Upstox API

    Data: NSE website (live) + NSEpy (historical)
    Analytics: Custom Black-Scholes Greeks
    Execution: Upstox API v2

    **Disclaimer:** Educational use only. Not SEBI registered.
    """)
