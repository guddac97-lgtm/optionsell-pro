"""
NSE Option Chain data fetcher using NSEpy + NSE website scraping
Falls back between sources for reliability
"""
import json
from datetime import datetime, timedelta
from typing import Dict, List, Optional
import pandas as pd

# NSEpy for historical + option chain
try:
    from nsepy import get_history
    from nsepy.derivatives import get_option_chain
    NSEPY_AVAILABLE = True
except ImportError:
    NSEPY_AVAILABLE = False

# Requests for NSE website scraping
import requests
from bs4 import BeautifulSoup


# ─── NSEpy Data Fetcher ──────────────────────────────────────────
def fetch_option_chain_nsepy(symbol: str, expiry_date: datetime) -> Optional[pd.DataFrame]:
    """Fetch option chain using NSEpy library"""
    if not NSEPY_AVAILABLE:
        return None
    try:
        chain = get_option_chain(symbol=symbol, expiry_date=expiry_date)
        if chain is not None and not chain.empty:
            return chain
    except Exception:
        pass
    return None


def fetch_historical_data_nsepy(symbol: str, days: int = 365) -> Optional[pd.DataFrame]:
    """Fetch historical data using NSEpy"""
    if not NSEPY_AVAILABLE:
        return None
    try:
        end_date = datetime.now()
        start_date = end_date - timedelta(days=days)
        data = get_history(symbol=symbol, start=start_date, end=end_date)
        return data if not data.empty else None
    except Exception:
        return None


# ─── NSE Website Scraping (Real-time fallback) ──────────────────
NSE_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
    "Accept": "application/json, text/plain, */*",
    "Accept-Language": "en-US,en;q=0.9",
    "Referer": "https://www.nseindia.com/",
}

NSE_INDEX_URLS = {
    "NIFTY": "https://www.nseindia.com/api/option-chain-indices?symbol=NIFTY",
    "BANKNIFTY": "https://www.nseindia.com/api/option-chain-indices?symbol=BANKNIFTY",
}


def fetch_option_chain_nse(symbol: str, session: requests.Session = None) -> Optional[dict]:
    """Fetch live option chain from NSE website"""
    url = NSE_INDEX_URLS.get(symbol)
    if not url:
        return None

    try:
        s = session or requests.Session()
        # First hit the main page to get cookies
        s.get("https://www.nseindia.com", headers=NSE_HEADERS, timeout=10)
        time.sleep(1)

        resp = s.get(url, headers=NSE_HEADERS, timeout=15)
        if resp.status_code == 200:
            return resp.json()
    except Exception:
        pass
    return None


def parse_nse_option_chain(raw_data: dict) -> List[Dict]:
    """Parse NSE API response into structured option chain"""
    if not raw_data or "records" not in raw_data:
        return []

    chain = []
    records = raw_data.get("records", {}).get("data", [])

    for record in records:
        ce_data = record.get("CE", {})
        pe_data = record.get("PE", {})

        strike = record.get("strikePrice", 0)

        if ce_data:
            chain.append({
                "strike": strike,
                "type": "CE",
                "oi": ce_data.get("openInterest", 0),
                "oi_change": ce_data.get("changeinOpenInterest", 0),
                "volume": ce_data.get("totalTradedVolume", 0),
                "ltp": ce_data.get("lastPrice", 0),
                "bid": ce_data.get("bidprice", 0),
                "ask": ce_data.get("askPrice", 0),
                "iv": ce_data.get("impliedVolatility", 0),
                "delta": ce_data.get("delta", 0),
                "theta": ce_data.get("theta", 0),
                "vega": ce_data.get("vega", 0),
                "gamma": ce_data.get("gamma", 0),
            })

        if pe_data:
            chain.append({
                "strike": strike,
                "type": "PE",
                "oi": pe_data.get("openInterest", 0),
                "oi_change": pe_data.get("changeinOpenInterest", 0),
                "volume": pe_data.get("totalTradedVolume", 0),
                "ltp": pe_data.get("lastPrice", 0),
                "bid": pe_data.get("bidprice", 0),
                "ask": pe_data.get("askPrice", 0),
                "iv": pe_data.get("impliedVolatility", 0),
                "delta": pe_data.get("delta", 0),
                "theta": pe_data.get("theta", 0),
                "vega": pe_data.get("vega", 0),
                "gamma": pe_data.get("gamma", 0),
            })

    return chain


def get_option_chain(symbol: str) -> List[Dict]:
    """Main function: fetch option chain with fallback strategy"""
    # Try NSE website first (live data)
    raw = fetch_option_chain_nse(symbol)
    if raw:
        chain = parse_nse_option_chain(raw)
        if chain:
            return chain

    # Fallback to NSEpy
    next_expiry = get_next_expiry_date(symbol)
    if next_expiry:
        df = fetch_option_chain_nsepy(symbol, next_expiry)
        if df is not None:
            return nsepy_to_chain_format(df)

    return []


def nsepy_to_chain_format(df: pd.DataFrame) -> List[Dict]:
    """Convert NSEpy DataFrame to our chain format"""
    chain = []
    for _, row in df.iterrows():
        for opt_type in ["CE", "PE"]:
            chain.append({
                "strike": row.get("Strike Price", 0),
                "type": opt_type,
                "oi": row.get(f"Open Interest{opt_type}", 0),
                "oi_change": 0,
                "volume": row.get(f"Number of Contracts{opt_type}", 0),
                "ltp": row.get(f"Last Price{opt_type}", 0),
                "bid": row.get(f"Bid Price{opt_type}", row.get(f"Last Price{opt_type}", 0)),
                "ask": row.get(f"Ask Price{opt_type}", row.get(f"Last Price{opt_type}", 0)),
                "iv": row.get(f"Close Volatility{opt_type}", 0),
                "delta": 0,
                "theta": 0,
                "vega": 0,
                "gamma": 0,
            })
    return chain


def get_next_expiry_date(symbol: str) -> Optional[datetime]:
    """Get next expiry date for an index"""
    today = datetime.now()
    days_to_thursday = (3 - today.weekday()) % 7
    if days_to_thursday == 0 and today.hour >= 15:
        days_to_thursday = 7
    return today + timedelta(days=days_to_thursday)


def fetch_spot_price(symbol: str) -> Optional[float]:
    """Fetch current spot price"""
    try:
        s = requests.Session()
        s.get("https://www.nseindia.com", headers=NSE_HEADERS, timeout=10)

        url = f"https://www.nseindia.com/api/equity-stockIndices?index={symbol}%20Nifty%2050"
        if symbol == "BANKNIFTY":
            url = f"https://www.nseindia.com/api/equity-stockIndices?index=Nifty%20Bank"

        resp = s.get(url, headers=NSE_HEADERS, timeout=15)
        if resp.status_code == 200:
            data = resp.json()
            return data.get("data", [{}])[0].get("lastPrice", 0)
    except Exception:
        pass
    return None


def fetch_historical_spot(symbol: str, days: int = 365) -> Optional[pd.DataFrame]:
    """Fetch historical spot price data"""
    if NSEPY_AVAILABLE:
        return fetch_historical_data_nsepy(symbol, days)

    # Fallback: Yahoo Finance
    try:
        import yfinance as yf
        ticker = "^NSEI" if symbol == "NIFTY" else "^NSEBANK"
        ticker_obj = yf.Ticker(ticker)
        hist = ticker_obj.history(period=f"{days}d", interval="1d")
        if not hist.empty:
            return hist
    except Exception:
        pass
    return None
