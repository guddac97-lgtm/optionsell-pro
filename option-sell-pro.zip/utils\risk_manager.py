"""
Risk Management Engine
Portfolio limits, per-trade checks, stop loss, profit booking rules
"""
from typing import Dict, List, Tuple
from datetime import datetime
from config import (
    MAX_RISK_PER_TRADE_PCT, CAPITAL, MAX_PORTFOLIO_DEPLOY_PCT,
    PROFIT_BOOKING_PCT, STOP_LOSS_MULTIPLIER, DAILY_LOSS_LIMIT_PCT
)
from database.db import get_open_positions, get_monthly_stats


def check_trade_eligibility(rec: dict, capital_available: float, margin_used: float) -> Tuple[bool, List[str]]:
    """
    Check if a recommended trade can be executed based on risk rules
    Returns (eligible: bool, reasons: list)
    """
    reasons = []

    # 1. Check max risk per trade
    max_risk = rec.get("max_risk", 0)
    max_allowed_risk = CAPITAL * (MAX_RISK_PER_TRADE_PCT / 100)
    if max_risk > max_allowed_risk:
        reasons.append(f"Max risk ₹{max_risk:,.0f} exceeds limit ₹{max_allowed_risk:,.0f}")

    # 2. Check portfolio deploy limit
    new_margin = margin_used + rec.get("margin", 0)
    max_allowed_deploy = CAPITAL * (MAX_PORTFOLIO_DEPLOY_PCT / 100)
    if new_margin > max_allowed_deploy:
        reasons.append(f"Portfolio deploy ₹{new_margin:,.0f} exceeds limit ₹{max_allowed_deploy:,.0f}")

    # 3. Check available capital
    if rec.get("margin", 0) > capital_available:
        reasons.append(f"Insufficient margin. Need ₹{rec['margin']:,.0f}, available ₹{capital_available:,.0f}")

    # 4. Check score threshold
    if rec.get("score", 0) < 70:
        reasons.append(f"Score {rec['score']} below minimum threshold 70")

    # 5. Check daily loss limit
    stats = get_monthly_stats()
    if stats["net_pnl"] < -(CAPITAL * DAILY_LOSS_LIMIT_PCT / 100):
        reasons.append(f"Daily loss limit hit: ₹{stats['net_pnl']:,.0f}")

    eligible = len(reasons) == 0
    return eligible, reasons


def check_position_exit_rules(position: dict) -> Tuple[str, str]:
    """
    Check if a position should be closed based on exit rules
    Returns (action: str, reason: str)
    Actions: 'HOLD', 'BOOK_PROFIT', 'CLOSE_SL', 'CLOSE_DTE'
    """
    profit_pct = position.get("profit_pct", 0)
    current_pnl = position.get("current_pnl", 0)
    max_profit = position.get("max_profit", 1)
    dte_left = position.get("dte_left", 99)
    entry_premium = position.get("entry_premium", 0)

    # Rule 1: 50% profit booking
    if profit_pct >= PROFIT_BOOKING_PCT:
        return "BOOK_PROFIT", f"Profit at {profit_pct:.0f}% - Book {PROFIT_BOOKING_PCT}%"

    # Rule 2: Stop loss (2x premium collected)
    if entry_premium > 0:
        loss_multiple = abs(current_pnl) / entry_premium if entry_premium > 0 else 0
        if loss_multiple >= STOP_LOSS_MULTIPLIER:
            return "CLOSE_SL", f"Loss hit {loss_multiple:.1f}x premium - Stop loss triggered"

    # Rule 3: 21 DTE rule
    if dte_left <= 3:
        return "CLOSE_DTE", f"Only {dte_left} days left - Close before expiry"

    # Rule 4: Max loss reached
    max_risk = position.get("max_risk", 0)
    if max_risk > 0 and abs(current_pnl) >= max_risk * 0.8:
        return "CLOSE_SL", f"Loss approaching max risk - Close position"

    return "HOLD", ""


def get_portfolio_risk_summary() -> Dict:
    """Get current portfolio risk metrics"""
    positions = get_open_positions()
    total_margin = sum(p.get("margin_used", 0) for p in positions)
    total_max_profit = sum(p.get("max_profit", 0) for p in positions)
    total_max_risk = sum(p.get("max_risk", 0) for p in positions)
    total_pnl = sum(p.get("current_pnl", 0) for p in positions)

    # Capital allocation check
    deploy_pct = (total_margin / CAPITAL * 100) if CAPITAL > 0 else 0

    return {
        "open_positions": len(positions),
        "total_margin_used": round(total_margin, 0),
        "total_max_profit": round(total_max_profit, 0),
        "total_max_risk": round(total_max_risk, 0),
        "current_pnl": round(total_pnl, 0),
        "deploy_pct": round(deploy_pct, 1),
        "can_deploy_more": deploy_pct < (MAX_PORTFOLIO_DEPLOY_PCT - 2),  # 2% buffer
        "positions_at_risk": sum(1 for p in positions if p.get("current_pnl", 0) < 0),
        "positions_profitable": sum(1 for p in positions if p.get("current_pnl", 0) > 0),
    }
