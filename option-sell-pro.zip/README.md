# OptionSell Pro — NSE Option Selling Recommendation Tool

Zero Cost • Live Data • Mobile First • Semi-Auto Execution

## Features

- Live NSE option chain data (free)
- Multi-factor scoring engine (0-100) for option selling trades
- 4 strategies: Iron Condor, Bull Put Spread, Bear Call Spread, Short Strangle
- One-click execution via Upstox API
- Risk management engine (SL, profit booking, portfolio limits)
- Trade journal with performance analytics
- Backtesting module
- Mobile-first UI (responsive, touch-friendly)

## Quick Start

```bash
# 1. Clone / download the project
cd option-sell-pro

# 2. Install dependencies
pip install -r requirements.txt

# 3. Setup Upstox API credentials
cp .env.example .env
# Edit .env with your Upstox API keys

# 4. Run the app
streamlit run app.py
```

## Deploy to Render (Free)

1. Push code to GitHub
2. Connect repo to [Render.com](https://render.com)
3. Set environment variables in Render dashboard
4. Deploy — app will be live at `yourapp.onrender.com`

## Mobile Access

After deploying:
1. Open app URL in mobile browser
2. Tap "Share" → "Add to Home Screen"
3. App opens like a native mobile app

## Tech Stack

| Component | Tool |
|---|---|
| UI | Streamlit |
| Data | NSE website (live) + NSEpy (historical) |
| Analytics | Custom Python (Black-Scholes, ADX, IV Rank) |
| Execution | Upstox API v2 |
| Database | SQLite |
| Charts | Plotly |

## Disclaimer

**Educational use only. Not SEBI registered research. Options trading involves significant risk of loss. Trade at your own risk. Past performance ≠ future returns.**
