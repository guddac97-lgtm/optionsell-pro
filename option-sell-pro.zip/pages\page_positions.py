"""
Positions Page - Active trades with live P&L tracking
"""
import streamlit as st
from datetime import datetime
from database.db import get_open_positions, get_portfolio_risk_summary
from utils.risk_manager import check_position_exit_rules


def show_positions():
    """Display open positions"""
    st.markdown("### 📂 Open Positions")

    positions = get_open_positions()

    if not positions:
        st.info("📭 No open positions. Generate recommendations and execute trades to see them here.")
        return

    # Portfolio Greeks summary
    risk = get_portfolio_risk_summary()
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("Total Margin", f"₹{risk['total_margin_used']:,.0f}")
    with col2:
        st.metric("Total P&L", f"₹{risk['current_pnl']:,.0f}",
                  delta=f"{risk['positions_profitable']}W/{risk['positions_at_risk']}L")
    with col3:
        st.metric("Max Risk", f"₹{risk['total_max_risk']:,.0f}")
    with col4:
        st.metric("Max Profit", f"₹{risk['total_max_profit']:,.0f}")

    st.markdown("---")

    # Display each position
    for pos in positions:
        _render_position_card(pos)


def _render_position_card(pos: dict):
    """Render a single position card"""
    pnl = pos.get("current_pnl", 0)
    profit_pct = pos.get("profit_pct", 0)
    dte = pos.get("dte_left", 99)

    # Determine status
    if pnl > 0 and profit_pct >= 50:
        status = "🟢 Profit Booking"
        status_color = "#00c853"
    elif pnl > 0:
        status = "🟢 In Profit"
        status_color = "#00c853"
    elif pnl < 0 and abs(pnl) >= pos.get("max_risk", 0) * 0.5:
        status = "🔴 At Risk"
        status_color = "#e94560"
    else:
        status = "🟡 Running"
        status_color = "#ff9800"

    # Check exit rules
    action, reason = check_position_exit_rules(pos)

    st.markdown(f"""
    <div style="
        background: #1a1a2e; border-radius: 16px; padding: 16px;
        margin-bottom: 12px; border: 1px solid #2a2a4a;
    ">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
            <div>
                <div style="font-size: 16px; font-weight: 700; color: #fff;">{pos['strategy']} • {pos['index_name']}</div>
                <div style="font-size: 12px; color: #888;">Expiry: {pos['expiry_date']} • Score: {pos.get('score', 0)}</div>
            </div>
            <div style="
                padding: 4px 12px; border-radius: 8px;
                background: {status_color}20; color: {status_color};
                font-size: 12px; font-weight: 600;
            ">{status}</div>
        </div>

        <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 8px; margin-bottom: 12px;">
            <div style="background: #1e1e3a; border-radius: 10px; padding: 10px; text-align: center;">
                <div style="font-size: 18px; font-weight: 700; color: {'#00c853' if pnl > 0 else '#e94560'};">{'+' if pnl > 0 else ''}₹{pnl:,.0f}</div>
                <div style="font-size: 10px; color: #888;">P&L</div>
            </div>
            <div style="background: #1e1e3a; border-radius: 10px; padding: 10px; text-align: center;">
                <div style="font-size: 18px; font-weight: 700; color: {'#00c853' if profit_pct > 0 else '#e94560'};">{profit_pct:.0f}%</div>
                <div style="font-size: 10px; color: #888;">Profit %</div>
            </div>
            <div style="background: #1e1e3a; border-radius: 10px; padding: 10px; text-align: center;">
                <div style="font-size: 18px; font-weight: 700; color: #fff;">{dte}</div>
                <div style="font-size: 10px; color: #888;">DTE Left</div>
            </div>
        </div>
    """, unsafe_allow_html=True)

    # Exit recommendation
    if action != "HOLD":
        st.info(f"💡 **{action}**: {reason}")

    # Action buttons
    col_adjust, col_close = st.columns(2)
    with col_adjust:
        if st.button("📐 Adjust", key=f"adjust_{pos['id']}", use_container_width=True):
            st.info("Adjustment panel coming soon. For now, use 'Close Now' to exit.")
    with col_close:
        if st.button("🔴 Close Now", key=f"close_{pos['id']}", use_container_width=True, type="secondary"):
            from database.db import close_position
            net_pnl, result = close_position(pos["id"], pos["entry_premium"], "Manual close")
            st.success(f"Position closed! Net P&L: ₹{net_pnl:,.0f} ({result})")
            st.rerun()

    st.markdown("</div>", unsafe_allow_html=True)
