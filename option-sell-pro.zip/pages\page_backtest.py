"""
Backtest Page - Test strategies on historical data
"""
import streamlit as st
from datetime import datetime, timedelta
from typing import Dict, List
import pandas as pd
import plotly.graph_objects as go

from data.nse_data import fetch_historical_spot, get_option_chain
from analytics.scoring import score_recommendation
from analytics.greeks import (
    black_scholes_greeks, time_to_expiry_years, get_risk_free_rate,
    calculate_iv_rank, fetch_historical_spot
)
from strategies.iron_condor import find_iron_condor
from strategies.bull_put_spread import find_bull_put_spread
from strategies.bear_call_spread import find_bear_call_spread
from config import INDICES, INDEX_DISPLAY, LOT_SIZE, CAPITAL
from database.db import save_backtest_result


def show_backtest():
    """Backtesting interface"""
    st.markdown("### 🧪 Backtesting")

    # Parameters
    col1, col2 = st.columns(2)
    with col1:
        strategy = st.selectbox("Strategy", ["Iron Condor", "Bull Put Spread", "Bear Call Spread"])
        index_name = st.selectbox("Index", ["NIFTY", "BANKNIFTY"])
    with col2:
        start_date = st.date_input("From", value=datetime(2024, 1, 1))
        end_date = st.date_input("To", value=datetime(2025, 9, 30))
        capital = st.number_input("Capital (₹)", value=200000, min_value=50000, step=50000)

    if st.button("▶ Run Backtest", use_container_width=True, type="primary"):
        with st.spinner("Running backtest... This may take a minute."):
            results = _run_backtest(strategy, index_name, start_date, end_date, capital)

            if results:
                _display_backtest_results(results)

                # Save to database
                save_backtest_result(results)
            else:
                st.error("Backtest failed. Please check the parameters and try again.")


def _run_backtest(strategy: str, index_name: str, start_date: datetime,
                  end_date: datetime, capital: float) -> Dict:
    """Run backtest on historical data"""
    # Fetch historical data
    hist_data = fetch_historical_spot(index_name, days=365)
    if hist_data is None or hist_data.empty:
        return {}

    # Filter date range
    hist_data.index = pd.to_datetime(hist_data.index)
    mask = (hist_data.index >= pd.Timestamp(start_date)) & (hist_data.index <= pd.Timestamp(end_date))
    data = hist_data[mask].copy()

    if len(data) < 30:
        return {}

    # Simulate trades at weekly intervals
    trades = []
    current_capital = capital
    max_capital = capital
    max_drawdown = 0

    # Trade every 7 days (weekly)
    for i in range(0, len(data) - 7, 7):
        window = data.iloc[i:i + 30]  # 30-day window for context
        if len(window) < 20:
            continue

        spot_price = data.iloc[i]["Close"]

        # Simulate simplified scoring
        closes = window["Close"].tolist()
        highs = window["High"].tolist()
        lows = window["Low"].tolist()

        adx = _quick_adx(highs, lows, closes)

        # Simulate option chain (simplified)
        simulated_chain = _simulate_option_chain(spot_price)

        # Run strategy
        if strategy == "Iron Condor":
            setup = find_iron_condor(spot_price, simulated_chain, datetime.now())
        elif strategy == "Bull Put Spread":
            setup = find_bull_put_spread(spot_price, simulated_chain, datetime.now())
        elif strategy == "Bear Call Spread":
            setup = find_bear_call_spread(spot_price, simulated_chain, datetime.now())
        else:
            continue

        if not setup:
            continue

        # Simulate outcome (simplified: use actual price movement)
        entry_premium = setup.get("net_credit", 0)
        max_profit = setup.get("max_profit", 0)
        max_risk = setup.get("max_risk", 1)

        # Calculate exit price after 7 days
        exit_spot = data.iloc[min(i + 7, len(data) - 1)]["Close"]
        spot_change = abs(exit_spot - spot_price) / spot_price

        # Simplified P&L calculation
        if strategy == "Iron Condor":
            # Win if spot stays within short strikes
            short_put = setup["strikes"]["short_put"]
            short_call = setup["strikes"]["short_call"]
            if short_put < exit_spot < short_call:
                pnl = entry_premium * LOT_SIZE.get(index_name, 50)  # Full profit
            else:
                loss_pct = min(spot_change * 5, 0.8)  # Simplified
                pnl = entry_premium * LOT_SIZE.get(index_name, 50) * (1 - loss_pct * 10)
                pnl = -max_risk * loss_pct  # Loss
        else:
            # Simplified: win probability based on IV
            win_prob = 0.65 + (setup.get("iv_short", 15) - 15) * 0.01
            if pd.Series([win_prob]).sample(1).iloc[0] > 0.5:
                pnl = entry_premium * LOT_SIZE.get(index_name, 50) * 0.7
            else:
                pnl = -max_risk * 0.3

        # Update capital
        current_capital += pnl
        max_capital = max(max_capital, current_capital)
        drawdown = (max_capital - current_capital) / max_capital * 100
        max_drawdown = max(max_drawdown, drawdown)

        trades.append({
            "date": data.index[i],
            "entry_spot": spot_price,
            "exit_spot": exit_spot,
            "pnl": pnl,
            "result": "WON" if pnl > 0 else "LOST",
            "entry_premium": entry_premium,
            "max_profit": max_profit,
            "max_risk": max_risk,
        })

    if not trades:
        return {}

    # Calculate stats
    total_trades = len(trades)
    wins = sum(1 for t in trades if t["result"] == "WON")
    win_rate = (wins / total_trades * 100) if total_trades > 0 else 0
    total_profit = sum(t["pnl"] for t in trades)
    avg_rr = _calculate_avg_rr(trades)

    return {
        "strategy": strategy,
        "index_name": INDEX_DISPLAY.get(index_name, index_name),
        "start_date": start_date.strftime("%Y-%m-%d"),
        "end_date": end_date.strftime("%Y-%m-%d"),
        "capital": capital,
        "total_trades": total_trades,
        "wins": wins,
        "losses": total_trades - wins,
        "win_rate": round(win_rate, 1),
        "total_profit": round(total_profit, 0),
        "return_pct": round((total_profit / capital) * 100, 1),
        "avg_rr": round(avg_rr, 2),
        "max_drawdown": round(max_drawdown, 1),
        "trades": trades
    }


def _quick_adx(highs: list, lows: list, closes: list, period: int = 14) -> float:
    """Quick ADX calculation"""
    if len(closes) < period + 1:
        return 0
    import math
    plus_dm = []
    minus_dm = []
    for i in range(1, len(highs)):
        up = highs[i] - highs[i - 1]
        down = lows[i - 1] - lows[i]
        plus_dm.append(up if up > down and up > 0 else 0)
        minus_dm.append(down if down > up and down > 0 else 0)

    pdm = sum(plus_dm[:period]) / period
    mdm = sum(minus_dm[:period]) / period
    total = pdm + mdm
    if total == 0:
        return 0
    return round((abs(pdm - mdm) / total) * 100, 1)


def _simulate_option_chain(spot: float) -> list:
    """Create simulated option chain for backtesting"""
    chain = []
    strikes = []
    base = round(spot / 100) * 100  # Round to nearest 100

    for offset in range(-500, 600, 50):
        strike = base + offset
        strikes.append(strike)

    for strike in strikes:
        for opt_type in ["CE", "PE"]:
            distance = abs(strike - spot) / spot
            iv = 15 + distance * 30  # Higher IV further OTM

            # Simplified price
            intrinsic = max(spot - strike, 0) if opt_type == "CE" else max(strike - spot, 0)
            time_value = spot * 0.01 * (1 - distance * 2)
            ltp = max(intrinsic + time_value, 5)

            # Simplified Greeks
            if opt_type == "CE":
                delta = max(0.5 - distance * 2, 0.01) if strike > spot else min(0.5 + (1 - distance), 0.99)
            else:
                delta = -max(0.5 - distance * 2, 0.01) if strike < spot else -min(0.5 + (1 - distance), 0.99)

            chain.append({
                "strike": strike,
                "type": opt_type,
                "ltp": round(ltp, 2),
                "iv": round(iv, 1),
                "delta": round(delta, 4),
                "theta": round(-ltp * 0.05, 2),
                "vega": round(ltp * 0.1, 2),
                "gamma": round(0.001 / (distance + 0.1), 6),
                "oi": int(100000 / (distance + 0.1)),
                "bid": round(ltp * 0.98, 2),
                "ask": round(ltp * 1.02, 2),
            })

    return chain


def _calculate_avg_rr(trades: list) -> float:
    """Calculate average risk-reward ratio"""
    wins = [t for t in trades if t["result"] == "WON"]
    losses = [t for t in trades if t["result"] == "LOST"]
    if not losses:
        return 999
    avg_win = sum(abs(t["pnl"]) for t in wins) / len(wins) if wins else 0
    avg_loss = sum(abs(t["pnl"]) for t in losses) / len(losses) if losses else 1
    return avg_win / avg_loss if avg_loss > 0 else 0


def _display_backtest_results(results: Dict):
    """Display backtest results"""
    col1, col2, col3 = st.columns(3)
    with col1:
        profit_color = "#00c853" if results["total_profit"] > 0 else "#e94560"
        st.markdown(f"<h2 style='color: {profit_color};'>₹{results['total_profit']:,.0f}</h2>", unsafe_allow_html=True)
        st.caption(f"Total Profit • {results['return_pct']}% return on ₹{results['capital']:,.0f}")
    with col2:
        wr_color = "#00c853" if results["win_rate"] >= 60 else "#ff9800"
        st.markdown(f"<h2 style='color: {wr_color};'>{results['win_rate']}%</h2>", unsafe_allow_html=True)
        st.caption(f"Win Rate • {results['wins']}W / {results['losses']}L")
    with col3:
        st.markdown(f"<h2>{results['avg_rr']:.1f}</h2>", unsafe_allow_html=True)
        st.caption(f"Avg Risk:Reward • {results['total_trades']} trades")

    st.markdown("---")

    # Equity curve
    if "trades" in results and results["trades"]:
        trades = results["trades"]
        equity = [results["capital"]]
        for t in trades:
            equity.append(equity[-1] + t["pnl"])

        fig = go.Figure()
        fig.add_trace(go.Scatter(
            y=equity,
            mode="lines",
            name="Portfolio Value",
            line=dict(color="#e94560", width=2)
        ))
        fig.add_hline(y=results["capital"], line_dash="dash", line_color="#888",
                      annotation_text="Initial Capital")
        fig.update_layout(
            title="Equity Curve",
            template="plotly_dark",
            paper_bgcolor="#1a1a2e",
            plot_bgcolor="#0f0f1a",
            font=dict(color="#e0e0e0"),
            height=300,
            margin=dict(l=0, r=0, t=30, b=0)
        )
        st.plotly_chart(fig, use_container_width=True)

        # Max drawdown
        st.metric("Max Drawdown", f"{results['max_drawdown']:.1f}%")
