"""
Journal Page - Trade history and performance analytics
"""
import streamlit as st
from datetime import datetime
from database.db import get_journal_trades, get_monthly_stats


def show_journal():
    """Display trade journal and performance stats"""
    st.markdown("### 📔 Trade Journal")

    # Monthly stats
    stats = get_monthly_stats()
    month_name = datetime.now().strftime("%B %Y")

    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric(f"Win Rate ({month_name})", f"{stats['win_rate']:.0f}%")
    with col2:
        st.metric("Total Trades", stats["total_trades"])
    with col3:
        st.metric("Net P&L", f"₹{stats['net_pnl']:,.0f}",
                  delta="Profit" if stats["net_pnl"] > 0 else "Loss")
    with col4:
        st.metric("Avg R:R", f"1:{stats['avg_rr']:.1f}" if stats['avg_rr'] > 0 else "N/A")

    st.markdown("---")

    # Trade history
    trades = get_journal_trades(limit=50)

    if not trades:
        st.info("📭 No closed trades yet. Execute some trades to build your journal.")
        return

    # Filter options
    with st.expander("🔍 Filters"):
        col_filter1, col_filter2 = st.columns(2)
        with col_filter1:
            strategy_filter = st.selectbox("Strategy", ["All", "Iron Condor", "Bull Put Spread", "Bear Call Spread"])
        with col_filter2:
            result_filter = st.selectbox("Result", ["All", "Won", "Lost"])

    filtered_trades = trades
    if strategy_filter != "All":
        filtered_trades = [t for t in filtered_trades if t["strategy"] == strategy_filter]
    if result_filter != "All":
        filtered_trades = [t for t in filtered_trades if t["result"] == result_filter]

    # Display trades
    for trade in filtered_trades:
        pnl = trade.get("net_pnl", 0)
        is_win = trade["result"] == "WON"

        with st.container():
            col_a, col_b, col_c = st.columns([3, 1, 1])

            with col_a:
                st.markdown(f"**{trade['strategy']}** • {trade['index_name']}")
                st.caption(f"{trade['entry_date']} • Exp: {trade['expiry_date']} • {trade.get('exit_reason', '')}")

            with col_b:
                st.metric(
                    "P&L",
                    f"{'+' if pnl > 0 else ''}₹{pnl:,.0f}",
                    delta=f"{'Won' if is_win else 'Lost'}",
                    delta_color="normal" if is_win else "inverse"
                )

            with col_c:
                st.markdown(f"<span style='color: {'#00c853' if is_win else '#e94560'}; font-weight: 600;'>{'WON' if is_win else 'LOST'}</span>",
                           unsafe_allow_html=True)

            st.markdown("---")

    # Summary section
    st.markdown("### 📊 Summary")

    if trades:
        total_won = sum(1 for t in trades if t["result"] == "WON")
        total_lost = sum(1 for t in trades if t["result"] == "LOST")
        total_pnl = sum(t.get("net_pnl", 0) for t in trades)
        win_rate = (total_won / len(trades)) * 100 if trades else 0

        wins = [t for t in trades if t["result"] == "WON"]
        losses = [t for t in trades if t["result"] == "LOST"]
        avg_win = sum(t["net_pnl"] for t in wins) / len(wins) if wins else 0
        avg_loss = sum(t["net_pnl"] for t in losses) / len(losses) if losses else 0
        rr = abs(avg_win / avg_loss) if avg_loss != 0 else 0

        col_s1, col_s2, col_s3, col_s4 = st.columns(4)
        with col_s1:
            st.metric("Total Trades", len(trades))
        with col_s2:
            st.metric("Win Rate", f"{win_rate:.0f}%", delta=f"{total_won}W / {total_lost}L")
        with col_s3:
            st.metric("Avg Win", f"₹{avg_win:,.0f}")
        with col_s4:
            st.metric("Avg Loss", f"₹{avg_loss:,.0f}", delta=f"R:R 1:{rr:.1f}")

        # Strategy performance breakdown
        st.markdown("#### Strategy Performance")
        strategy_stats = {}
        for t in trades:
            s = t["strategy"]
            if s not in strategy_stats:
                strategy_stats[s] = {"wins": 0, "losses": 0, "total_pnl": 0}
            if t["result"] == "WON":
                strategy_stats[s]["wins"] += 1
            else:
                strategy_stats[s]["losses"] += 1
            strategy_stats[s]["total_pnl"] += t.get("net_pnl", 0)

        for strategy, s_stats in strategy_stats.items():
            total = s_stats["wins"] + s_stats["losses"]
            wr = (s_stats["wins"] / total * 100) if total > 0 else 0
            st.write(f"**{strategy}**: {s_stats['wins']}W/{s_stats['losses']}L • WR: {wr:.0f}% • P&L: ₹{s_stats['total_pnl']:,.0f}")
