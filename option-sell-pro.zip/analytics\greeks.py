"""
Black-Scholes Greeks Calculator
Delta, Gamma, Theta, Vega, IV calculation
"""
import math
from scipy.stats import norm
from datetime import datetime


# ─── Black-Scholes Price & Greeks ────────────────────────────────
def black_scholes_greeks(S: float, K: float, T: float, r: float, sigma: float, option_type: str = "CE"):
    """
    Calculate Black-Scholes price and all Greeks

    Args:
        S: Spot price
        K: Strike price
        T: Time to expiry in years
        r: Risk-free rate (annual, decimal)
        sigma: Implied volatility (annual, decimal)
        option_type: 'CE' or 'PE'

    Returns:
        dict with price, delta, gamma, theta, vega, rho
    """
    if T <= 0 or sigma <= 0:
        # At expiry
        if option_type == "CE":
            price = max(S - K, 0)
            delta = 1.0 if S > K else 0.0
        else:
            price = max(K - S, 0)
            delta = -1.0 if S < K else 0.0
        return {
            "price": price, "delta": delta, "gamma": 0,
            "theta": 0, "vega": 0, "rho": 0
        }

    d1 = (math.log(S / K) + (r + 0.5 * sigma ** 2) * T) / (sigma * math.sqrt(T))
    d2 = d1 - sigma * math.sqrt(T)

    if option_type == "CE":
        price = S * norm.cdf(d1) - K * math.exp(-r * T) * norm.cdf(d2)
        delta = norm.cdf(d1)
        rho = K * T * math.exp(-r * T) * norm.cdf(d2)
    else:
        price = K * math.exp(-r * T) * norm.cdf(-d2) - S * norm.cdf(-d1)
        delta = norm.cdf(d1) - 1
        rho = -K * T * math.exp(-r * T) * norm.cdf(-d2)

    gamma = norm.pdf(d1) / (S * sigma * math.sqrt(T))
    vega = S * norm.pdf(d1) * math.sqrt(T) / 100  # Per 1% change in IV
    theta = -(S * norm.pdf(d1) * sigma) / (2 * math.sqrt(T)) / 365  # Per day

    return {
        "price": round(price, 2),
        "delta": round(delta, 4),
        "gamma": round(gamma, 6),
        "theta": round(theta, 2),
        "vega": round(vega, 2),
        "rho": round(rho, 2)
    }


# ─── IV Rank Calculator ─────────────────────────────────────────
def calculate_iv_rank(current_iv: float, historical_ivs: list) -> int:
    """
    Calculate IV Rank: where current IV stands relative to 1-year range

    IV Rank = (Current IV - 52-week Low IV) / (52-week High IV - 52-week Low IV) * 100
    """
    if not historical_ivs or len(historical_ivs) < 10:
        return 50  # Default mid-range

    iv_low = min(historical_ivs)
    iv_high = max(historical_ivs)

    if iv_high == iv_low:
        return 50

    iv_rank = ((current_iv - iv_low) / (iv_high - iv_low)) * 100
    return max(0, min(100, int(iv_rank)))


def calculate_iv_percentile(current_iv: float, historical_ivs: list) -> int:
    """
    Calculate IV Percentile: % of days where IV was below current IV
    """
    if not historical_ivs or len(historical_ivs) < 10:
        return 50

    below_count = sum(1 for iv in historical_ivs if iv < current_iv)
    return int((below_count / len(historical_ivs)) * 100)


def classify_iv_environment(iv_rank: int) -> str:
    """Classify IV environment"""
    if iv_rank >= 70:
        return "HIGH"
    elif iv_rank >= 40:
        return "NORMAL"
    elif iv_rank >= 20:
        return "LOW"
    else:
        return "VERY LOW"


# ─── ADX / Trend Strength ───────────────────────────────────────
def calculate_adx(high: list, low: list, close: list, period: int = 14) -> float:
    """
    Calculate ADX (Average Directional Index) for trend strength

    ADX > 25 = Strong trend
    ADX 20-25 = Moderate trend
    ADX < 20 = Weak trend / sideways
    """
    if len(close) < period + 1:
        return 0

    # +DM and -DM
    plus_dm = []
    minus_dm = []
    tr_list = []

    for i in range(1, len(high)):
        up_move = high[i] - high[i - 1]
        down_move = low[i - 1] - low[i]

        plus_dm.append(up_move if (up_move > down_move and up_move > 0) else 0)
        minus_dm.append(down_move if (down_move > up_move and down_move > 0) else 0)

        tr = max(
            high[i] - low[i],
            abs(high[i] - close[i - 1]),
            abs(low[i] - close[i - 1])
        )
        tr_list.append(tr)

    # Smooth with Wilder's method
    atr = sum(tr_list[:period])
    plus_di_smooth = sum(plus_dm[:period])
    minus_di_smooth = sum(minus_dm[:period])

    for i in range(period, len(tr_list)):
        atr = (atr * (period - 1) + tr_list[i]) / period
        plus_di_smooth = (plus_di_smooth * (period - 1) + plus_dm[i]) / period
        minus_di_smooth = (minus_di_smooth * (period - 1) + minus_dm[i]) / period

    if atr == 0:
        return 0

    plus_di = 100 * plus_di_smooth / atr
    minus_di = 100 * minus_di_smooth / atr

    dx_sum = 0
    dx_count = 0
    for i in range(period, len(tr_list)):
        if (plus_di_smooth + minus_di_smooth) == 0:
            dx = 0
        else:
            dx = 100 * abs(plus_di - minus_di) / (plus_di + minus_di)
        dx_sum += dx
        dx_count += 1

    adx = dx_sum / dx_count if dx_count > 0 else 0
    return round(adx, 1)


def get_trend_direction(close: list, period: int = 20) -> str:
    """Determine trend direction using SMA"""
    if len(close) < period:
        return "NEUTRAL"

    sma = sum(close[-period:]) / period
    current = close[-1]

    if current > sma * 1.005:
        return "BULLISH"
    elif current < sma * 0.995:
        return "BEARISH"
    else:
        return "NEUTRAL"


# ─── PCR (Put-Call Ratio) ───────────────────────────────────────
def calculate_pcr(put_oi: int, call_oi: int) -> float:
    """Calculate Put-Call Ratio from OI data"""
    if call_oi == 0:
        return 0
    return round(put_oi / call_oi, 2)


def interpret_pcr(pcr: float) -> str:
    """Interpret PCR reading"""
    if pcr > 1.5:
        return "OVERSOLD_BULLISH"  # Too many puts = bullish reversal likely
    elif pcr > 1.0:
        return "BULLISH"
    elif pcr > 0.7:
        return "NEUTRAL"
    elif pcr > 0.5:
        return "BEARISH"
    else:
        return "OVERSOLD_BEARISH"  # Too many calls = bearish reversal likely


# ─── Time Utilities ─────────────────────────────────────────────
def days_to_expiry(expiry_date: datetime) -> int:
    """Calculate days remaining to expiry"""
    if isinstance(expiry_date, str):
        expiry_date = datetime.strptime(expiry_date, "%Y-%m-%d")
    remaining = (expiry_date - datetime.now()).days
    return max(0, remaining)


def time_to_expiry_years(expiry_date: datetime) -> float:
    """Convert DTE to years for Black-Scholes"""
    return days_to_expiry(expiry_date) / 365.0


def get_risk_free_rate() -> float:
    """Get current risk-free rate (approximate, 10-year G-Sec yield)"""
    # Default: ~6.5% RBI repo rate area
    # Can be updated with live data from RBI website
    return 0.065
